Basic Res Cardiol (2011) 106:1173-1191

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_309_155_813_641.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_836_155_1341_634.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_324_663_810_1173.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_848_663_1341_1168.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_310_1201_810_1667.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-s00395-011-0222-8.pdf_10/image/D38A4021187959C5A4D40530D74C2F80_0_843_1201_1336_1667.jpeg)  
**Fig. 5** Effect of Akt overexpression (AOE) on aging-induced change in insulin receptor $ \beta $ (panel a), PDK1 phosphorylation (panel b), Akt phosphorylation (pAkt-to-Akt ratio) at Ser $ ^{473} $ (panel c) and Thr $ ^{308} $ (panel d), GSK3 $ \beta $ phosphorylation (pGSK3 $ \beta $ -to-GSK3 $ \beta $ ratio, panel e), and PTEN phosphorylation (pPTEN-to-PTEN ratio, panel f).   
Insets: representative gel blots depicting expression and phosphorylation of these proteins using specific antibodies. $ \alpha $ -Tubulin was used as the loading control. Mean $ \pm $ SEM, n = 5-7 mice per group, $ ^{*}p < 0.05 $ versus WT-young group, $ ^{\#}p < 0.05 $ versus WT-old group

an index for lysosomal activity [11, 33], was determined in young or aged WT and Akt transgenic mice. Our data failed to revealed altered $\beta$ -glucuronidase activity in

response to aging, Akt overactivation, or both. In addition, the levels of the two autophagy-related lysosomal proteins, cathepsin B and LAMP1, were examined [17, 22]. Neither

Springer