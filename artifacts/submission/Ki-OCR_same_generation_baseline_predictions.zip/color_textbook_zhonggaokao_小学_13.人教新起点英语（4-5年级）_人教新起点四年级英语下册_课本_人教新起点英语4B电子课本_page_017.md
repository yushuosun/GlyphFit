# Unit 2 Cities

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_017/image/1DE9DF905121B5EBAA16C4856E7FB001_0_0_196_1651_2219.jpeg)