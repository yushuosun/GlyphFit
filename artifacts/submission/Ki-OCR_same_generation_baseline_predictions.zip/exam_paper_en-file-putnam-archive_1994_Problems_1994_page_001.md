# The 55th William Lowell Putnam Mathematical Competition Saturday, December 3, 1994

A-1 Suppose that a sequence $a _ { 1 } , a _ { 2 } , a _ { 3 } , \dots$ satisfies $0 < a _ { n } \leq a _ { 2 n } + a _ { 2 n + 1 }$ for all $n \geq 1$ . Prove that the series $\sum _ { n = 1 } ^ { \infty } a _ { n }$ diverges.

A-2 Let $A$ be the area of the region in the first quadrant bounded by the line $y = \frac { 1 } { 2 } x$ , the $x$ -axis, and the ellipse $\frac { 1 } { 9 } x ^ { 2 } + y ^ { 2 } = 1$ . Find the positive number $m$ such that $A$ is equal to the area of the region in the first quadrant bounded by the line $y = mx$ , the $y$ -axis, and the ellipse $\frac { 1 } { 9 } x ^ { 2 } + y ^ { 2 } = 1$ .

A-3 Show that if the points of an isosceles right triangle of side length 1 are each colored with one of four colors, then there must be two points of the same color which are at least a distance $2 - \sqrt{2}$ apart.

A-4 Let $A$ and $B$ be $2 \times 2$ matrices with integer entries such that $A , A + B , A + 2 B , A + 3 B$ , and $A + 4 B$ are all invertible matrices whose inverses have integer entries. Show that $A + 5 B$ is invertible and that its inverse has integer
entries.

A-5 Let $(r_n)_{n \geq 0}$ be a sequence of positive real numbers such that $\lim_{n\to\infty} r_n = 0$ . Let $S$ be the set of numbers representable as a sum

$$r_{i_{1}}+r_{i_{2}}+\cdots+r_{i_{1994}},$$

with $i _ { 1 } < i _ { 2 } < \cdots < i _ { 1 9 9 4 }$ . Show that every nonempty interval $( a , b )$ contains a nonempty subinterval $( c , d )$ that does not intersect $S$ .

A-6 Let $f _ { 1 } , \ldots , f _ { 1 0 }$ be bijections of the set of integers such that for each integer $n$ ，there is some composition $f _ { i _ { 1 } } \circ f _ { i _ { 2 } } \circ \cdots \circ f _ { i _ { m } }$ of these functions (allowing repetitions) which maps 0 to $n$ . Consider the set of 1024 functions

$$\mathcal{F}=\{f_{1}^{e_{1}}\circ f_{2}^{e_{2}}\circ\cdots\circ f_{10}^{e_{10}}\},$$

$e _ { i } = 0$ or $1$ for $1 \leq i \leq 10$ . ( $f _ { i } ^ { 0 }$ is the identity function
and $f _ { i } ^ { 1 } = f _ { i } .$ ) Show that if $A$ is any nonempty finite set

of integers, then at most 512 of the functions in $\mathscr { F }$ map $A$ to itself.

B-1 Find all positive integers $n$ that are within 250 of exactly 15 perfect squares.

B-2 For which real numbers $c$ is there a straight line that intersects the curve

$$x^{4}+9x^{3}+cx^{2}+9x+4$$

in four distinct points?

B-3 Find the set of all real numbers $k$ with the following property: For any positive, differentiable function $f$ that satisfies $f ^ { \prime } ( x ) > f ( x )$ for all $x$ , there is some number $N$ such that $f ( x ) > e ^ { k x }$ for all $x > N$ .

B-4 For $n \geq 1$ , let $d_n$ be the greatest common divisor of the
entries of $A^n - I$ , where

$$A=\left(\begin{array}{cc}3&2\\ 4&3\end{array}\right)\quad and\quad I=\left(\begin{array}{cc}1&0\\ 0&1\end{array}\right).$$

Show that $\lim_{n\to\infty}d_n=\infty$ .

B-5 For any real number $\alpha$ ,define the function $f_{\alpha}(x) =$ $\lfloor\alpha x\rfloor$ . Let n be a positive integer. Show that there exists an $\alpha$ such that for $1 \leq k \leq n$

$$f_{\alpha}^{k}(n^{2})=n^{2}-k=f_{\alpha^{k}}(n^{2}).$$

B-6 For any integer $n$ , set

$$n_{a}=101a-100\cdot2^{a}.$$

Show that for $0 \leq a,b,c,d \leq 99,n_a + n_b \equiv n_c + n_d \pmod {10100}$ implies $\{a,b\} = \{c,d\}$ .