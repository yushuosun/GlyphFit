# Revision 1

# Let's Review

# A  Listen and number.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_043/image/48786B0A0915786E72E662C784E9C4D1_0_651_388_727_456.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_043/image/48786B0A0915786E72E662C784E9C4D1_0_80_474_750_1314.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_043/image/48786B0A0915786E72E662C784E9C4D1_0_886_458_1449_837.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_043/image/48786B0A0915786E72E662C784E9C4D1_0_907_895_1449_1309.jpeg)

# B Let's play.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_043/image/48786B0A0915786E72E662C784E9C4D1_0_72_1375_1452_2151.jpeg)