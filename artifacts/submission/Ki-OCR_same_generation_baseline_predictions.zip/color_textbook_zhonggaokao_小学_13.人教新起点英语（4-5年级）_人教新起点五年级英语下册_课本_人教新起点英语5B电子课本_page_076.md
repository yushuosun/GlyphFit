# B Do a survey and report.

When did you learn to swim, Joy?

When I was five.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_076/image/211EFDC6D94F94F5D295BA4B04EF5BD2_0_418_311_1289_863.jpeg)

<table border="1"><tr><td>name</td><td>Andy</td><td>Joy</td><td></td></tr><tr><td>started to use a computer</td><td></td><td></td><td></td></tr><tr><td>started to study English</td><td></td><td></td><td></td></tr><tr><td>went to kindergarten</td><td></td><td></td><td></td></tr><tr><td>started to speak</td><td></td><td></td><td></td></tr><tr><td>learned to swim</td><td></td><td>five</td><td></td></tr><tr><td>learned to ride a bike</td><td></td><td></td><td></td></tr><tr><td>learned to walk</td><td>one</td><td></td><td></td></tr></table>

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_076/image/211EFDC6D94F94F5D295BA4B04EF5BD2_0_236_1426_854_1747.jpeg)

I learned to walk when
I was one year old.
Joy learned to swim at five ...

# C  Let's write.

Fill in the blanks according to the survey.

Joy ____ when she was five.

Andy ____ when he was ____.