To estimate area $A$
under $y = 3x^2$ from

$$x=2\;to\;x=4$$

![](images/PPT_fundamental_theorem_of_calculus___page_002/image/A0A711990C71B2DF40232709AC570C19_0_996_49_1650_451.jpeg)

we could split it into small rectangles:

With 4 rectangles,
the area $\approx 48.96 \text{ units}^2$

![](images/PPT_fundamental_theorem_of_calculus___page_002/image/A0A711990C71B2DF40232709AC570C19_0_1004_820_1664_1237.jpeg)