Y. Sun, P.S.P. Tse / Journal of Computational Physics 230 (2011) 2076-2094

![](images/docstructbench_llm-raw-scihub-o.O-j.jcp.2010.12.006.pdf_14/image/B33A9582695A85D807839C6F5B33D9D4_0_193_148_740_682.jpeg)  
(a)

![](images/docstructbench_llm-raw-scihub-o.O-j.jcp.2010.12.006.pdf_14/image/B33A9582695A85D807839C6F5B33D9D4_0_759_148_1303_682.jpeg)  
(b)

![](images/docstructbench_llm-raw-scihub-o.O-j.jcp.2010.12.006.pdf_14/image/B33A9582695A85D807839C6F5B33D9D4_0_193_738_737_1276.jpeg)  
(c)

![](images/docstructbench_llm-raw-scihub-o.O-j.jcp.2010.12.006.pdf_14/image/B33A9582695A85D807839C6F5B33D9D4_0_762_740_1303_1276.jpeg)  
(d)   
Fig. 4. The dispersion contours with stepsizes $ \Delta t=0.01, $ $ \Delta=0.1 $ for Maxwell's equations (46) from (a) exact dispersion; (b) boxscheme; (c) symplectic method and (d) Yee's method. The constant contour values are $ \omega\in[2,4,6,\ldots,24] $ .

$$\varphi=\tan^{-1}\left(\frac{(\upsilon_{g})_{y}}{(\upsilon_{g})_{x}}\right),\quad|v_g|=\sqrt{(\upsilon_{g})_{x}^{2}+(\upsilon_{g})_{y}^{2}}.\tag{48}$$

Substituting into (48) the vectors $\kappa$ and ${v}_{g}$ in polar coordinates (44), and let $a = \left| \kappa \right| \Delta$ , this yields the propagation angle $\varphi$ and the propagation speed ${\left| {v}_{g}\right| }$ in terms of $a$ and $\theta$ .

For example, $\varphi$ for the boxscheme is given by

$$\varphi=\tan^{-1}\left(\frac{\sin\left(\frac{1}{2}\sin(\theta)a\right)\cos^{3}\left(\frac{1}{2}\cos(\theta)a\right)}{\cos^{3}\left(\frac{1}{2}\sin(\theta)a\right)\sin\left(\frac{1}{2}\cos(\theta)a\right)}\right).$$

Taking the Taylor expansion of this expression with respect to $a = 0$ yields,

$$\varphi\approx\theta-\frac{1}{12}\sin(4\theta)a^{2}+O(a^{3}).\tag{49}$$

Similarly, the Taylor expansion of $|v_{g}|$ at a = 0 yields,

$$\left|{v}_{g}\right|\approx 1+\left({\frac{1}{16}\cos\left({4\theta}\right)-\frac{{r}^{2}}{4}+\frac{3}{16}}\right){a}^{2}+O\left({a}^{4}\right),\tag{50}$$