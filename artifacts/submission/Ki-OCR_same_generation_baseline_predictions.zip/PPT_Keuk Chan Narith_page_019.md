# An Emergence of English language Variety in Cambodia

$\Leftarrow$ Some of these features are caused by non-equivalence in the two languages in phonological propositions in the form of language transfer and overgeneralization of the target language.