# Let's Check

# A  Listen and put the things into the right bag.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_97_322_388_907.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_505_327_803_512.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_839_458_1152_643.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_1264_378_1555_881.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_464_657_795_846.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_833_785_1173_982.jpeg)

# B Let's play.

Choose a picture and make a dialogue.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_94_1153_818_1639.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_843_1153_1572_1639.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_055/image/B3002883B76AC183223052D7DA95DFF8_0_95_1667_1555_2121.jpeg)