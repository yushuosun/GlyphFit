2.1 Vector Spaces and Subspaces

1. $x+y=y+x.$   
2. $x + ( y + z ) = ( x + y ) + z .$   
3. There is a unique "zero vector" such that $x + 0 = x$ for all $x$ .   
4. For each $x$ there is a unique vector $- x$ such that $x + (- x ) = 0$ .   
5. $1 x=x.$   
6. $( c_{1} c_{2} ) x=c_{1} ( c_{2} x ).$   
7. $c ( x + y ) = c x + c y$   
8. $( c_{1}+c_{2} ) x=c_{1} x+c_{2} x.$   
(a) Suppose addition in $\mathbf{R}^2$ adds an extra 1 to each component, so that $(3,1)+(5,0)$ equals (9,2）instead of (8,1). With scalar multiplication unchanged, which rules are broken?   
(b) Show that the set of all positive real numbers, with $x+y$ and $cx$ redefined to equal
the usual $xy$ and $x^c$ , is a vector space. What is the "zero vector"?   
(c) Suppose $(x_{1},x_{2})+(y_{1},y_{2})$ is defined to be $(x_{1}+y_{2},x_{2}+y_{1})$ . With the usual
$cx=(cx_{1},cx_{2})$ ,which of the eight conditions are not satisfied?

6. Let $\mathbf{P}$ be the plane in 3-space with equation $x + 2y + z = 6$ . What is the equation of the plane $\mathbf{P}_0$ through the origin parallel to $\mathbf{P}$ ? Are $\mathbf{P}$ and $\mathbf{P}_0$ subspaces of $\mathbf{R}^3$ ?

7. Which of the following are subspaces of ${\mathbf{R}}^{\infty }$ ?

(a) All sequences like $\left( {1,0,1,0,\ldots }\right)$ that include infinitely many zeros.   
(b) All sequences $\left( {x1,x2,\ldots }\right)$ with ${x}_{j}=0$ from some point onward.   
(c) All decreasing sequences: $x _ { j + 1 } \leq x _ { j }$ for each $j$   
(d) All convergent sequences: the $x _ { j }$ have a limit as $j \to \infty .$   
(e) All arithmetic progressions: $x _ { j + 1 } - x _ { j }$ is the same for all $\boldsymbol { j }$ .   
(f) All geometric progressions $\left( {{x}_{1},{k}{x}_{1},{k}^{2}{x}_{1},\ldots }\right)$ allowing all $k$ and ${x}_{1}$ .

8. Which of the following descriptions are correct? The solutions $x$ of

$$Ax=\left[\begin{array}{ccc}1&1&1\\ 1&0&2\end{array}\right]\left[\begin{array}{c}x_1\\ x_2\\ x_3\end{array}\right]=\left[\begin{array}{c}0\\ 0\end{array}\right]$$

form

(a) a plane.   
(b) a line.   
(c) a point.   
(d) a subspace.