HOMOGENEOUS LINEAR SYSTEMS

■ Example 1: Determine if the following homogeneous
system has a nontrivial solution. Then describe the
solution set.

$$3x_{1}+5x_{2}-4x_{3}=0$$

$$-3x_1-2x_2+4x_3=0$$

$$6x_{1}+x_{2}-8x_{3}=0$$

■ Solution: Let $A$ be the matrix of coefficients of the
system and row reduce the augmented matrix $[A \quad 0]$
to echelon form:

© 2016 Pearson Education, Inc.