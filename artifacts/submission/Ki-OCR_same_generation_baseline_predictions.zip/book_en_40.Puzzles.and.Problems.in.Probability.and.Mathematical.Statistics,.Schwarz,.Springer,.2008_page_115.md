Solutions

The last two expectations in this expression are known from the basic result about $\mathrm{E}\left[ \mathbf{U}\right]$ so that the only really new part concerns the expectation of the product $\mathbf{{UV}}$ . Now, by the definition of $\mathbf{U},\mathbf{V}$

$$\mathbf{UV}=\exp(\mathbf{X})\cdot\exp(\mathbf{Y})=\exp(\mathbf{X}+\mathbf{Y})$$

Let the rv $\mathbf{S} = \mathbf{X} + \mathbf{Y}$ . Clearly, $\mathbf{S}$ is normally distributed, with mean $\mu_{s}=$ $\mu_{x}+\mu_{y}$ and variance $\sigma_{s}^{2}=\sigma_{x}^{2}+\sigma_{y}^{2}+2\varrho\sigma_{x}\sigma_{y}$ . It then follows from the basic result about $E[\mathbf{U}]$ that

$$\mathsf{E}[\mathbf{UV}]=\mathsf{E}[\exp(\mathbf{S})]$$

$$=\mathrm{exp}\left(\mu_{s}+\frac{1}{2}\sigma_{s}^{2}\right)$$

Putting together this result — with ${\mu }_{s},{\sigma }_{s}$ expressed in terms of the original parameters as earlier — and the previously known facts about the means and variances of U, V, the correlation coefficient is, after slight simplification, found to be

$$\mathrm{corr}(\mathbf{U},\mathbf{V})=\frac{\exp(\varrho\sigma_x\sigma_y)-1}{\sqrt{\left[\exp(\sigma_x^2)-1\right]\left[\exp(\sigma_y^2)-1\right]}}$$

Note that the correlation between $\mathbf{U}$ and $\mathbf{V}$ is completely independent of the means of $\mathbf{X}$ and $\mathbf{Y}$ . As explained earlier, the exponentiation turns the location parameters ${\mu }_{x},{\mu }_{y}$ of $\mathbf{X}$ and $\mathbf{Y}$ into scaling factors of $\mathbf{U}$ and $\mathbf{V}$ . Because variations of the scaling factors generally do not change linear correlations, the result was to be expected. On the other hand, the standard deviations ${\sigma }_{x},{\sigma }_{y}$ of $\mathbf{X}$ and $\mathbf{Y}$ turn into powers for $\mathbf{U}$ and $\mathbf{V}$ , which generally do influence the linear correlation coefficient.

The result about the correlation of $\mathbf{U}$ and $\mathbf{V}$ may also be used to verify the properties we already discussed in part c. Note, in particular, that in the equal-variance case $\sigma _ { x } = \sigma _ { y } = \sigma$ we get

$$\mathrm{corr}(\mathbf{U},\mathbf{V})=\frac{\exp(\varrho\sigma^2)-1}{\exp(\sigma^2)-1}$$

The correlation of $\mathbf{U}$ and $\mathbf{V}$ is shown in Figure 3.25 as a function of the correlation $\varrho$ of the original rvs $\mathbf{X}$ and $\mathbf{Y}$ , for three values of $\sigma$ . For $\varrho = +1$ , the two correlations are identical, but for any other value the correlation between $\mathbf{U}$ and $\mathbf{V}$ is weaker than that between $\mathbf{X}$ and $\mathbf{Y}$ .