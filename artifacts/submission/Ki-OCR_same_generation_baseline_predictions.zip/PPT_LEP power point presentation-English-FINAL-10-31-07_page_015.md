# Thank You!

![](images/PPT_LEP power point presentation-English-FINAL-10-31-07_page_015/image/537FFED12D6DE869EF541A92C7782E46_0_662_562_1230_1252.jpeg)

“...promoting the well-being and safety of our children, families and communities....”