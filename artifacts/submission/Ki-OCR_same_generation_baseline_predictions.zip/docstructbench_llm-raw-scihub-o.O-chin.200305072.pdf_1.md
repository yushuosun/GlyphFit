Polycarboxylic acids and esters

Polycarboxylic acids and esters

P 0253

05-072

Michael Addition of Nitroalkanes to Dimethyl Citraconate, with DBU as Base: An Unexpected, One-Pot Synthesis of Polyfunctionalized Carbonyl Derivatives.   
— The direct formation of keto diesters $(\mathrm{III})$ from nitroalkanes and dimethyl citraconate proceeds via an isomerization of the double bond of $(\mathrm {II})$ followed by Michael addition of the anion derived from (I) and a Nef-type conversion. The expected adducts $(\mathrm {IV})$ are not observed. — $(\mathrm {BALLINI}^{*},\mathrm {R}. ; \mathrm {BARBONI},\mathrm {L}. ; \mathrm {BOSICA},\mathrm {G}. ; \mathrm {FIORINI},\mathrm {D}. ;$ GIL, M. V.; Synlett 2002, 10, 1706-1708; Dip. Sci. Chim., Univ. Camerino, I-62032 Camerino, Macerata, Italy; Eng.) — Mais

![](images/docstructbench_llm-raw-scihub-o.O-chin.200305072.pdf_1/image/D213563B436128F5AF1DA400AD8D9516_0_275_381_881_753.jpeg)