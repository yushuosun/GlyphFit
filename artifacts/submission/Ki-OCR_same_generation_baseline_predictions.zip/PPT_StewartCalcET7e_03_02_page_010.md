# Example 1

(a) If $f ( x ) = x e ^ { x }$ , find $f ^ { \prime } ( x )$ .   
(b) Find the $nth$ derivative, $f^{(n)}(x)$ .

# Solution:

(a) By the Product Rule, we have

$$f^{\prime}(x)=\frac{d}{dx}\left(xe^{x}\right)$$

$=x\frac{d}{dx}(e^x)+e^x\frac{d}{dx}$ (x)

$$=xe^{x}+e^{x}\cdot 1=(x+1)e^{x}$$