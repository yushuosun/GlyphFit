![](images/book_en_搬书匠-3396-iPhone The Missing Manual 10th Edition-2017-英文版_page_099/image/A1FBC28E17C41D2DA67F04233FEAA33E_0_126_100_588_907.jpeg)

![](images/book_en_搬书匠-3396-iPhone The Missing Manual 10th Edition-2017-英文版_page_099/image/A1FBC28E17C41D2DA67F04233FEAA33E_0_602_100_1064_907.jpeg)

it.) Each time you tap it, you rotate to the next keyboard you requested earlier. The new language's name appears briefly on the space bar to identify it.

Thanks to that 🌐 button, you can freely mix languages and alphabets within the same document without having to duck back to some control panel to make the change. And thanks to the iPhone's virtual keyboard, the actual letters on the "keys" change in real time.

The 🌐 button works in three ways:

- Tap it once to restore the most recent keyboard. Great if you're frequently flipping back and forth between two languages.   
- Tap it rapidly to cycle among all the keyboards you've selected. (The name of the language appears briefly on the space bar to help you out.)   
• If you, some United Nations translator, like to write in a lot of different languages, you don't have to tap that 🌐 key over and over again to cycle through the keyboard layouts. Instead, hold your finger down

Typing, Editing & Searching