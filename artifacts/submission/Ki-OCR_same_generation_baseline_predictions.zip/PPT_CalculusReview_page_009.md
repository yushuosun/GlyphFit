# Partial Derivatives

![](images/PPT_CalculusReview_page_009/image/0DA835194A622A9EA06A42AFD66D1F54_0_438_306_1276_1065.jpeg)

![](images/PPT_CalculusReview_page_009/image/0DA835194A622A9EA06A42AFD66D1F54_0_1426_496_1568_897.jpeg)

• Functions of more than one variable   
• Example: $C ( x , y ) = x ^ { 4 } + y ^ { 3 } + x y$