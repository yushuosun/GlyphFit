18 Interpolation of Polynomials

3. (Singapore) $^4$ Let $f$ be a polynomial of degree $n$ , such that $f(k) = \frac{k}{k+1}$ for every integer $0 \le k \le n$ . Compute $f(n+1)$ .   
4. $(\mathrm{U S A})^{5}$ Let f be a real polynomial of degree n, such that $f ( k )=\binom{n+1} {k}^{-1}$ for $0 \leq k \leq n$ . Compute all possible values of $f ( n + 1 )$ .   
5. (IMO一shortlist) A polynomial $f$ ，of degree 990, is such that $f(k) = {F}_{k}$ for ${992} \leq k \leq {1982}$ , where ${F}_{k}$ stands for the $k$ -th Fibonacci number. Prove that $f\left( {1983}\right) = {F}_{1983} - 1$ .   
6. (IMO-shortlist) Let $f$ be a real polynomial such that   
(a) $f ( 1 ) > f ( 0 ) > 0.$   
(b) $f ( 2 ) > 2 f ( 1 ) - f ( 0 )$ .   
(c) $f ( 3 ) > 3 f ( 2 ) - 3 f ( 1 ) + f ( 0 )$ .   
(d) $f ( n + 4 ) > 4 f ( n + 3 ) - 6 f ( n + 2 ) + 4 f ( n + 1 ) - f ( n )$ for every $n \in \mathbb { N }$ .   
Prove that $f ( n ) > 0$ for every $n \in \mathbb { N }$ .