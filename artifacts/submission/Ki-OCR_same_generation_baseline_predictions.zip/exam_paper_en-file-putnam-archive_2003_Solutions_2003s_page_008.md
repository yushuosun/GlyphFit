where

$$C_{j}=\#\{i<j:\operatorname{sgn}(a_{i})=\operatorname{sgn}(a_{j})\}$$

$$-\#\{i<j:\operatorname{sgn}(a_i)\neq\operatorname{sgn}(a_j)\}.$$

Consider the partial sum $P _ { k } = \sum _ { j = 1 } ^ { k } C _ { j }$ . If exactly $p _ { k }$ of $a _ { 1 } , \ldots , a _ { k }$ are positive, then this sum is equal to

$$\binom{p_k}{2}+\binom{k-p_k}{2}-\left[\binom{k}{2}-\binom{p_k}{2}-\binom{k-p_k}{2}\right],$$

which expands and simplifies to

$$-2p_k(k-p_k)+\binom{k}{2}.$$

For $k \leq 2p$ even, this partial sum would be minimized with $p_k = \frac{k}{2}$ , and would then equal $-\frac{k}{2}$ ; for $k < 2p$ odd, this partial sum would be minimized with $p_k = \frac{k \pm 1}{2}$ , and would then equal $-\frac{k-1}{2}$ . Either way, $P_k \geq -\lfloor \frac{k}{2} \rfloor$ . On the other hand, if $k > 2p$ , then

$$-2p_{k}(k-p_{k})+\binom{k}{2}\geq-2p(k-p)+\binom{k}{2}$$

since $p_k$ is at most $p$ . Define $Q_k$ to be $-\lfloor \frac{k}{2} \rfloor$ if $k \leq 2p$ and $-2p(k-p) + \binom{k}{2}$ if $k \geq 2p$ , so that $P_k \geq Q_k$ . Note that $Q_1 = 0$ .

Partial summation gives

$$\sum_{j=1}^{n}r_{j}C_{j}=r_{n}P_{n}+\sum_{j=2}^{n}(r_{j-1}-r_{j})P_{j-1}$$

$$\geq r_nQ_n+\sum_{j=2}^{n}(r_{j-1}-r_j)Q_{j-1}$$

$$=\sum_{j=2}^{n}r_j(Q_j-Q_{j-1})$$

$$=-r_2-r_4-\cdots-r_{2p}+\sum_{j=2p+1}^{n}(j-1-2p)r_j.$$

It follows that

$$\sum_{1\leq i<j\leq n}|a_{i}+a_{j}|=\sum_{i=1}^{n}(n-i)r_{i}+\sum_{j=1}^{n}r_{j}C_{j}$$

$$\geq\sum_{i=1}^{2p}(n-i-[i\mathrm{~even}])r_i$$

$$+\sum_{i=2p+1}^{n}(n-1-2p)r_i$$

$$=(n-1-2p)\sum_{i=1}^{n}r_{i}$$

$$+\sum_{i=1}^{2p}(2p+1-i-[i\text{even}])r_i$$

$$\geq(n-1-2p)\sum_{i=1}^{n}r_{i}+p\sum_{i=1}^{2p}r_{i}$$

$$\geq(n-1-2p)\sum_{i=1}^{n}r_{i}+p\frac{2p}{n}\sum_{i=1}^{n}r_{i},$$

as desired. The next-to-last and last inequalities each follow from the monotonicity of the $r _ { i }$ 's, the former by pairing the $i ^ { \mathrm { t h } }$ term with $\left( 2 p + 1 - i \right) ^ { \mathrm { t h } }$ .

Note: Compare the closely related Problem 6 from the 2000 USA Mathematical Olympiad: prove that for any nonnegative real numbers $a _ { 1 } , \ldots , a _ { n } , b _ { 1 } , \ldots , b _ { n }$ ,one has

$$\mathop{\sum}\limits_{{i,j=1}}^{n}\operatorname*{min}\left\{{a}_{i}{a}_{j},{b}_{i}{b}_{j}\right\}\leq\mathop{\sum}\limits_{{i,j=1}}^{n}\operatorname*{min}\left\{{{a}_{i}{b}_{j},{a}_{j}{b}_{i}}\right\}.$$