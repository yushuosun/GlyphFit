# REQUIREMENTS-1

- Each group is required to present,
with TWO options:

1. A short video summary in 1 min PLUS a classroom live presentation in 6-8 min;

<table border="1"><tr><td>1-min video byMar 11</td><td>Tutorial: 6-8 min classroomlive presentation</td><td>7-10 min tutorialdiscussion, Q&amp;A</td></tr></table>

2. A full video presentation in 5-7 min;

<table border="1"><tr><td>~6-min full video by Mar 11</td><td>Tutorial: introduction and view video presentation</td><td>7-10 min tutorial discussion, Q&amp;A</td></tr></table>

□ ALL videos due on Mar 11, 2016;

ENGG1000 Presentation Specification

5/21/2025