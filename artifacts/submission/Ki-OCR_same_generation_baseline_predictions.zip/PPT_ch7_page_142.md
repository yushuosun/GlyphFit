(continued 3)

SUMMARY OF CHAPTER 7

Linear Algebra: Matrices, Vectors,
Determinants. Linear Systems

The transpose $\mathbf{A}^{\mathsf{T}}$ of a matrix $\mathbf{A} = [a_{jk}]$ is $\mathbf{A}^{\mathsf{T}} = [a_{jk}]$ ; rows
become columns and conversely (Sec. 7.2). Here, $\mathbf{A}$ need not
be square. If it is and $\mathbf{A} = \mathbf{A}^{\mathsf{T}}$ , then $\mathbf{A}$ is called symmetric; if
$\mathbf{A} = -\mathbf{A}^{\mathsf{T}}$ , it is called skew-symmetric.

For a product, $\mathbf{(A B )}^{\mathsf{T}}=\mathbf{B}^{\mathsf{T}}\mathbf{A}^{\mathsf{T}}$ (Sec. 7.2).

A main application of matrices concerns linear systems of
equations

(2)

$$\mathbf{A}\mathbf{x}=\mathbf{b}$$

(Sec. 7.3)

(m equations in $n$ unknowns $x_1, \ldots, x_n$ ; $\mathbf{A}$ and $\mathbf{b}$ given).

Section 7.Summary p142

Advanced Engineering Mathematics, $10/e$ by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.