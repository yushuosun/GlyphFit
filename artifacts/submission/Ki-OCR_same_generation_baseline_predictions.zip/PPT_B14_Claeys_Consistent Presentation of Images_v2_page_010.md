# Monitor Characteristic Curve

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_010/image/264DC61483775643C7E6C299CEA9AE6F_0_190_747_290_912.jpeg)  
Monitor Characteristic Curve   
Ambient Light

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_010/image/264DC61483775643C7E6C299CEA9AE6F_0_516_431_1536_1132.jpeg)

Slide Provided by David Clunie, Quintiles Intelligent Imaging