eg if $y = f(x) = 3x^2$ and $a=2$ and $b=4$

then Area A $=\int_{2}^{4} 3x^{2} dx$

$$=\Bigg[x^3\Bigg]_2^4$$

$$=\left[4^3\right]-\left[2^3\right]$$

$$=64-8$$

$$=56\mathrm{units}^{2}$$

![](images/PPT_fundamental_theorem_of_calculus___page_013/image/2CFA02C2F9547421B102F89D946316A5_0_896_481_1662_1078.jpeg)