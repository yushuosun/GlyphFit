Generally, this is what we could do:

Area of 1 rectangle $\approx f(x) \times h$

![](images/PPT_fundamental_theorem_of_calculus___page_005/image/40F48DBF2AF8EFC95333DE141989C690_0_1064_139_1510_652.jpeg)

Area of all the rectangles $\approx \sum f(x) \times h$

Actual area under the curve = $\lim_{h \to 0} \sum f(x) x h$

which is written as $\int f(x)dx$

( but evaluating this limit is incredibly complicated)