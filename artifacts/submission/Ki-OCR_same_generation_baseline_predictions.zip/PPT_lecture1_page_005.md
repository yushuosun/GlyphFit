# System of linear equations

A collection of one or more equations involving the same variables.

Example:

The system of linear equations $\begin{cases} 2x_{1} + 3x_{2} + 4x_{3} = 5 \\ 5x_{3} + 6x_{4} = 7 \end{cases}$

can be rewritten as $\left\{ \begin{array}{l} 2x_{1} + 3x_{2} + 4x_{3} + 0x_{4} = 5 \\ 0x_{1} + 0x_{2} + 5x_{3} + 6x_{4} = 7 \end{array} \right.$

Hence it is a system of equations involving the variables $x_1, x_2, x_3, x_4$ .