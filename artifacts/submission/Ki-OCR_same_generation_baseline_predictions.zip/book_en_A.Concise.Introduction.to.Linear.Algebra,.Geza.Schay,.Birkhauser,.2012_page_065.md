2. Systems of Linear Equations, Matrices

Exercise 2.1.3. $2x_{1}+2x_{2}-3x_{3}=0$

$$x_{1}+5x_{2}+2x_{3}=1$$

Exercise 2.1.4. $2x_{1}+2x_{2}-3x_{3}=0$

In the next nine exercises use Gaussian elimination to find all solutions of the systems given by their augmented matrices.

Exercise 2.1.5. $\left[ \begin{array}{rrr|r}{1}&{0}&{-1}&{0}\\ {-2}&{3}&{-1}&{0}\\ {-6}&{6}&{0}&{0}\end{array}\right]$

Exercise 2.1.6. $\left[ \begin{array}{ccc|c} 1 & 0 & -1 & 1 \\ - 2 & 3 & -1 & 0 \\ - 6 & 6 & 0 & - 2 \end{array} \right]$

Exercise 2.1.7. $\left[ \begin{array}{rrr|r}{1}&{0}&{-1}&{1}\\ {-2}&{3}&{-1}&{0}\\ {-6}&{6}&{0}&{0}\end{array} \right]$

Exercise 2.1.8. $\left[ \begin{array}{rrrrr|r}{3}&{-6}&{-1}&{1}&{12}\\ {-1}&{2}&{2}&{3}&{1}\\ {6}&{-8}&{-3}&{-2}&{9}\end{array} \right]$

Exercise 2.1.9. $\left[ \begin{array}{rrrrr|r}{1}&{4}&{9}&{2}&{0}\\ {2}&{2}&{6}&{-3}&{0}\\ {2}&{7}&{16}&{3}&{0}\end{array} \right]$

Exercise 2.1.10. $\left[ \begin{array}{rrr|r}{2}&{4}&{1}&{7}\\ {0}&{1}&{3}&{7}\\ {3}&{3}&{-1}&{9}\\ {1}&{2}&{3}&{11}\end{array}\right]$

Exercise 2.1.11. $\left[ \begin{array}{rrrrr|r}{3}&{-6}&{-1}&{1}&{5}&{0}\\ {-1}&{2}&{2}&{3}&{3}&{0}\\ {4}&{-8}&{-3}&{-2}&{1}&{0}\end{array}\right]$

Exercise 2.1.12. $\left[ \begin{array}{rrrrr|r}{3}&{-6}&{-1}&{1}&{7}\\ {-1}&{2}&{2}&{3}&{1}\\ {4}&{-8}&{-3}&{-2}&{6}\end{array} \right]$

Exercise 2.1.13. $\left[ \begin{array}{rrrrr|r}{3}&{-6}&{-1}&{1}&{5}\\ {-1}&{2}&{2}&{3}&{3}\\ {6}&{-8}&{-3}&{-2}&{1}\end{array} \right]$