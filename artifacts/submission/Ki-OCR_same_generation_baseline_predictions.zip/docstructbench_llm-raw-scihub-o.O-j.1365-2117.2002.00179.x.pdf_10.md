T. Muto and R. J. Steel

![](images/docstructbench_llm-raw-scihub-o.O-j.1365-2117.2002.00179.x.pdf_10/image/1DEB3274C6065A01A3EC156D35860E47_0_264_154_1469_1089.jpeg)  
Fig. 10. Reconstructed shoreline trajectories. Note that the trajectories for $ y_{i}=0. 4 5 \, \pm\, 0. 1 0 $ show concave-basinward geometry.

$y_{i}=0. 4 5 \, \pm\, 0. 1 0$ , however, the trend of steady increase in S is still retained.With $y_{i}=0. 4 5$ , the magnitude of S in the middle stage, when the shelf edge was located somewhere between sites P-M, is three times as large as in the initial stage.In the latest stage, furthermore, the magnitude of S became over 14 times as large as in the initial stage. A significantly different trend of S is seen with $y_{i} \geq0. 7 0$ km: S decreases in the early stage and then increases later. It is an important point that, whatever magnitude $y_{i}$ took, S tended to become highest at the latest stage, when the shelf edge was migrating from site M to site D.

The pattern of changing $A$ , opposite to that of changing $S$ (Eq. (10)), is shown in Fig. 12 in the form of a relative sea-level curve. When $y_i$ takes a low magnitude (e.g. 0.05-0.20 km), the relative sea-level change is characterized with a rapid rise in the early stage followed by a slow rise or nearly a standstill in the late stage. This trend is also seen in the case of $y_i = 0.45 \pm 0.10$ km. When $y_i = 0.80$ km, there was no change in $A$ while the shelf edge was prograding from site i to site M. With $y_i \geq 0.85$ km, the relative sea-level curve is sigmoidal in shape where the highest magnitude of $A$ is realized between sites P and M.

# Assessment of the uncertainty

The results of the analyses of the uncertainty of the field data and related assumptions are shown in Figs 13 and 14.

Polygons $\eta_{\mathrm{P}}$ , $\eta_{\mathrm{M}}$ , and $\eta_{\mathrm{D}}$ in the $x-y$ plane represent the spatial distribution of any possible $x_{\mathrm{a d v}}$ , that was obtained from the data sets measured at sites P, M, and D, respectively. The degree of overlap between polygons is expressed as $\rho_{\mathrm{P M}}$ (for overlap between $\eta_{\mathrm{P}}$ and $\eta_{\mathrm{M}}$ ) and $\rho_{\mathrm{M D}}$ (for overlap between $\eta_{\mathrm{M}}$ and $\eta_{\mathrm{D}}$ ) (see Eq. (11)).

There is no overlap between $\eta_{\mathrm{P}}$ and $\eta_{\mathrm{M}}$ (i.e. $\rho_{\mathrm{P M}}=0$ ）when $y_{\mathrm{i}}\leq0. 3 5$ km and $y_{\mathrm{i}}\geq1. 0 5$ km .With $y_{\mathrm{i}}=0. 4 0-1. 0 0$ km ， on the other hand, $\eta_{\mathrm{P}}$ and $\eta_{\mathrm{M}}$ overlap each other (i.e. $0<\rho_{\mathrm{P M}}<1$ ）. However， the highest value of $\rho_{\mathrm{P M}}$ (at $y_{\mathrm{i}}$ = 0.40 km) is as low as 0.137. Excluding the cases that $y_{\mathrm{i}}=0. 4 0-0. 4 5$ km ，the overlap is negligible $\left( \rho_{\mathrm{P M}}\approx0 \right).$ On the other hand， the overlap of $\eta_{\mathrm{M}}$ and $\eta_{\mathrm{D}}$ is in a significantly different trend from that between $\eta_{\mathrm{P}}$ and $\eta_{\mathrm{M}}$ . There is some overlap between $\eta_{\mathrm{M}}$ and $\eta_{\mathrm{D}}$ （ $0<\rho_{\mathrm{M D}}$ ）when $y_{\mathrm{i}}=$ 0.20-0.90 km . At any magnitude of $y_{\mathrm{i}}$ within this range, $\rho_{\mathrm{M D}}$ is much larger than that of $\rho_{\mathrm{P M}}$ (Fig. 14). The highest values of $\rho_{\mathrm{M D}}$ (0.55-0.60) are seen when $y_{\mathrm{i}}=0. 5 0-$ 0.70 km .With $y_{\mathrm{i}}=0. 4 5 \pm0. 1 0$ km, $\rho_{\mathrm{M D}}$ ranges between 0.31 and 0.55, still much larger than the highest of $\rho_{\mathrm{P M}}.$

# Interpretation

The clear monomodal distribution of ‘successful’ runs (Fig. 9) suggests that the initial water depth $（y_{i}）$  for the shelf-edge progradation is most likely to have been around 0.45 km . Less attention needs to be paid to other

$ \textcircled{c} $ 2002 Blackwell Science Ltd, Basin Research, 14, 303-318