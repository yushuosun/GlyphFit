Pyrrole derivatives

Pyrrole derivatives

R 0120

27-104

Anti-HIV-1 Activity of Pyrryl Aryl Sulfone (PAS) Derivatives: Synthesis and SAR Studies of Novel Esters and Amides at the Position 2 of the Pyrrole Nucleus. —   
Of all tested compounds, compound (IVa) shows the highest antiviral activity. — (SILVESTRI $^{*}$ , R.; ARTICO, M.; LA REGINA, G.; DE MARTINO, G.; LA COLLA, M.; LODDO, R.; COLLA $^{*}$ , P.; Farmaco 59 (2004) 3, 201-210; Dip. Stud. Farm., Univ. La Sapienza, I-00185 Roma, Italy; Eng.) — C. Oppel

![](images/docstructbench_llm-raw-scihub-o.O-chin.200427104.pdf_1/image/2E7C07BA1F6ED2AC1CD13468AF42EB6E_0_292_342_865_874.jpeg)