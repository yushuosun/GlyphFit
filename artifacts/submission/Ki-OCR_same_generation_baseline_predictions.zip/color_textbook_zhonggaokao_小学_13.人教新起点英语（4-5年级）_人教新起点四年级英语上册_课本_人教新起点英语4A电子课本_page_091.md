# Unit 5

# A  Listen, point and repeat.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_191_355_492_575.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_520_357_864_575.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_886_367_1479_575.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_183_685_471_1017.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_553_675_904_1012.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_967_687_1461_1022.jpeg)

# 三年级下册

# Unit 1

# A  Listen, point and say.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_157_1375_515_1653.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_626_1377_980_1653.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_1082_1377_1439_1653.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_158_1663_514_1943.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_624_1663_980_1941.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_091/image/5156B613FDB43675BD1C24B7F6595113_0_1082_1663_1439_1941.jpeg)