# 第四课 口语部分Part 2详解下

轻松搞定

KET 口语25分

# 内容提要

KET 口语part 2 问题卡怎么看  
KET 口语part 2 重点句型  
KET 口语part 2 信息卡、问题卡综合训练  
KET 口语part 2 专项训练

![](images/color_textbook_zhonggaokao_小学_KET听说读写逐项突破_KET听说读写逐项突破之轻松搞定KET口语25分【10 褚连一】_第04讲第四课口语部分Part2详解下_第四课口语部分Part2详解下_page_001/image/E7168F68C37AA15DB3427CEBA3001AAF_0_105_916_1022_1559.jpeg)

![](images/color_textbook_zhonggaokao_小学_KET听说读写逐项突破_KET听说读写逐项突破之轻松搞定KET口语25分【10 褚连一】_第04讲第四课口语部分Part2详解下_第四课口语部分Part2详解下_page_001/image/E7168F68C37AA15DB3427CEBA3001AAF_0_1307_94_2308_707.jpeg)

# KET 口语 part 2 考试技巧

• Give clear answers   
- Only use the information in the booklet   
-  Can't get higher marks for adding extra information

# KET 口语 part 2 重点句型

- 问名字：What's the name of the show?   
- 问日期：When's the show?   
- 问时间：What time dose the show start？  
- 问地址：Where's the show?