# WHY BOTHER GIVING A GOOD TALK?

○ First impressions matter!

○ There's no point doing good work if others don't know about it or can't understand what you did.

Good practice for a teaching career! Good practice for any career!

![](images/PPT_BaharMartonosi_page_002/image/F532E881F807C023FEDCD2FD3976D73B_0_22_807_174_909.jpeg)

Helps you sort out what you've done, and understand it better yourself.