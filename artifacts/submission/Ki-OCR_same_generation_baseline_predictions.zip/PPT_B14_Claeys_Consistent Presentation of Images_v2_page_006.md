# Problems of Inconsistency

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_006/image/F4A7FF13C4D707D0096912CC177F9FCA_0_230_212_920_955.jpeg)

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_006/image/F4A7FF13C4D707D0096912CC177F9FCA_0_1046_212_1736_952.jpeg)

● Printed images don't look like displayed images

Slide Provided by David Clunie, Quintiles Intelligent Imaging