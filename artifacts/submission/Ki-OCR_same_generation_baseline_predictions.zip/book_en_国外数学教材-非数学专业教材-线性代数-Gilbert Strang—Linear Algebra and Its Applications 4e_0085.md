Chapter 1 Matrices and Gaussian Elimination

(b) Construct a matrix that has $column1+2(�(�)3)=0$ .Check that $A$ is singular (fewer than 3 pivots) and explain why that must be the case.

1.27 True or false, with reason if true and counterexample if false:

(1) If $L _ { 1 } U _ { 1 } = L _ { 2 } U _ { 2 }$ (upper triangular $U$ 's with nonzero diagonal, lower triangular $L$ 's with unit diagonal), then $L _ { 1 } = L _ { 2 }$ and $U _ { 1 } = U _ { 2 }$ . The $L U$ factorization is unique.   
(2) If $A^{2}+A=I$ then $A^{-1}=A+I.$   
(3) If all diagonal entries of $A$ are zero, then $A$ is singular.

1.28 By experiment or the Gauss-Jordan method compute

$$\left[\begin{array}{ccc}{1}&{0}&{0}\\ {\ell}&{1}&{0}\\ {m}&{0}&{1}\end{array}\right]^{n},\qquad\left[\begin{array}{ccc}{1}&{0}&{0}\\ {\ell}&{1}&{0}\\ {m}&{0}&{1}\end{array}\right]^{-1},\qquad\left[\begin{array}{ccc}{1}&{0}&{0}\\ {\ell}&{1}&{0}\\ {0}&{m}&{1}\end{array}\right]^{-1}.$$

1.29 Write down the 2 by 2 matrices that

(a) reverse the direction of every vector.   
(b) project every vector onto the $x _ { 2 }$ axis.   
(c) turn every vector counterclockwise through ${90}^{ \circ }$ .   
(d) reflect every vector through the $4 5^{\circ}$ line $x_{1}=x_{2}.$