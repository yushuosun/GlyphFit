# Determinant of a Matrix

Used for inversion

If $\det(\mathrm{A}) = 0$ , then $\mathrm{A}$ has no inverse

$$A=\left[\begin{array}{cc}a&b\\ c&d\end{array}\right]$$

$$\det(A)=ad-bc$$

$$A^{-1}={\frac{1}{ad-bc}}{\left[\begin{array}{ll}{d}&{-b}\\ {-c}&{a}\end{array}\right]}$$

http://www.euclideanspace.com/maths/algebra/matrix/functio
ns/inverse/threeD/index.htm

Rensselaer Polytechnic Institute

Shivkumar Kalyanaraman

Google": "shiv rpi"