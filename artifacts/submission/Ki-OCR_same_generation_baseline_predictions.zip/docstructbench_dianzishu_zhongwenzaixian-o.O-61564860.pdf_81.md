围棋定式解密

# 32飞

从原有棋子出发，向“日”字形的对角线交点处下一子叫 “飞”，也叫“小飞”。

图2-116 相对于图中原有的白棋一子来说，无论白方在A、B、C、D、E、F、G、H这些字母代表的位置上任意一处行棋，都可以称其为飞。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61564860.pdf_81/image/81AA18B2C89A7C911F58963619DF0E15_0_604_447_1005_721.jpeg)  
图2-116

图2-117相对于白方原有的一子来说，白 $\triangle$ 是飞。反过来，相对于白方 $\triangle$ 一子，白原有的一子也叫作飞。

飞的形式里还有“大飞”。它是指在原有棋子呈“目”字形的对角线交点处行棋。

图2-118白 $\triangle$ 就叫白棋原有一子的大飞。同样，假若白方今后在A、B、C、D、E、F、G任何一处行棋，都叫大飞。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61564860.pdf_81/image/81AA18B2C89A7C911F58963619DF0E15_0_168_1139_576_1469.jpeg)  
图2-117

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61564860.pdf_81/image/81AA18B2C89A7C911F58963619DF0E15_0_603_1139_1005_1469.jpeg)  
图2-118