# HELP + NOUN + V

![](images/PPT_session 10_page_023/image/B3E7E8E8158D795CC3CEB87237FB270A_0_160_451_1802_1021.jpeg)

[help].[vv*] [n*] [v*i]