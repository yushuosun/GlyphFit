# Enclosed Basic Switches

North American limit switches are also available in an enclosed basic version. These switches are designated by the catalog number 3SE03-EB. Enclosed basic switches are preconfigured with a plunger actuator, booted plunger, roller lever, booted roller lever, roller plunger, or a booted roller plunger.

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_635_404_800_578.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_858_407_948_578.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1205_407_1370_578.jpeg)  
Booted Roller Lever

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1426_402_1518_578.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_635_609_795_732.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_856_609_948_732.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1205_605_1363_732.jpeg)  
Booted Plunger

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1424_602_1518_732.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_635_745_795_886.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_856_745_948_886.jpeg)

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1205_745_1363_886.jpeg)  
Booted Roller Plunger

![](images/docstructbench_enbook-zlib-o.O-17342542.pdf_25/image/7AAB4FAC272950EBC78185AAFFA4B5DB_0_1424_741_1518_886.jpeg)