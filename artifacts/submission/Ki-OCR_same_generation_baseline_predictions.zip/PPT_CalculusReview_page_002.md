# Slope

• Slope = rise/run   
$\bullet$ = $\Delta y / \Delta x$   
• $= \left( y_{2}-y_{1} \right)/\left( x_{2}-x_{1} \right)$   
- Order of points 1 and 2 not critical, but keeping them together is   
• Points may lie in any quadrant: slope will work out   
• Leibniz notation for derivative based on $\Delta y / \Delta x$ ; the derivative is written $dy/dx$

![](images/PPT_CalculusReview_page_002/image/71D0FE1F0FB8CC29B1D2D1665AE6BD7B_0_1052_363_1950_1260.jpeg)