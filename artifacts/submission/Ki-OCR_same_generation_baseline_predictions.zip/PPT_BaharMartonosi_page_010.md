# THE BIGGER PICTURE:

# COMMUNICATION AND YOUR CAREER

Expressing yourself technically
helps you make and use
professional connections wisely

You are joining a long-term community...

Communicate your ideas to forge
mentoring and technical
relationships in the service of
professional goals

![](images/PPT_BaharMartonosi_page_010/image/50DBF4ACC7DC8DEE02FBF86FF4150ECC_0_1192_346_1904_969.jpeg)