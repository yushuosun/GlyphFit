2-second pause in the dialing. You can type several of them to create longer pauses.

To change the label for a number (“mobile,” “home,” “work,” and so on), tap the label that's there now. The Label screen shows you your choices. There's even a label called “iPhone,” so you and your buddy can gloat together.

TIP: If you scroll down the Label screen, you'll see that you can also
create custom labels. You might prefer someone's cellphone number
to be identified as "cell" instead of "mobile," for example. Or you
might want to create a label that says "Skype," "Google Voice,
"Line 2," "Yacht Phone," or "Bat Phone." The secret: Tap Add Custom
Label. (Once you've created a custom label, it's there in the list of
options for your use later.)

![](images/book_en_搬书匠-3396-iPhone The Missing Manual 10th Edition-2017-英文版_page_126/image/84FCD3074D67D1812EA7DC76502DD017_0_156_610_607_1260.jpeg)

![](images/book_en_搬书匠-3396-iPhone The Missing Manual 10th Edition-2017-英文版_page_126/image/84FCD3074D67D1812EA7DC76502DD017_0_628_612_1077_1261.jpeg)

• Expand-O-Fields mean you'll never run out of room. Almost every field (empty box) on a Contacts card is infinitely expanding. That is, the instant you start filling in a field, another empty box (labeled + add phone or whatever) appears right below it, so you can immediately add another phone number, email address, URL, or street address. (The only nonexpanding fields are First name, Last name, Company, Ringtone, Text Tone, Notes, and whatever oddball fields you add yourself.)

Chapter 4