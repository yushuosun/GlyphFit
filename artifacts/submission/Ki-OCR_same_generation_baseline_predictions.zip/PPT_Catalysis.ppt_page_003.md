# Activation energy

• Molecules must be activated before they can undergo a reaction   
- Reactants must absorb enough energy from surroundings to destabilize chemical bonds (energy of activation)   
- Transition state   
– Intermediate stage in reaction where the reactant molecule is strained or distorted but the reaction has not yet occurred

![](images/PPT_Catalysis.ppt_page_003/image/5A98A0C34012DE2FAF4C195BC8B9A3BF_0_944_537_1914_1066.jpeg)