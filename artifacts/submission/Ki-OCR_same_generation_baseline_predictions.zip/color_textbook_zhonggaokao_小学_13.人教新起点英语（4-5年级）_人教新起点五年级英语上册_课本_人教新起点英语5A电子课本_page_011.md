# Let's Spell

# A  Listen, point and repeat.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_128_297_730_537.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_836_198_915_278.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_839_297_1449_537.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_128_580_730_818.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_839_580_1449_818.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_128_863_730_1104.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_839_863_1449_1104.jpeg)

# B  Listen,colour and repeat.

1. cl ock
bl ock   
2. bl ue   
3. cl ass   
4. $\boxed{sl}$ ow fl   
5.  $\boxed{f1}$  y   
6. $\boxed{pl}$ $ay$   
7. $\boxed{sl}$ ant   
8. gl ide

# C  Listen, write and say.

Ms ____ is slim. She wears ____. Her gloves are ____.

# D  Listen and repeat.

My little blue plane
Is flying in the sky.
It flies very slowly,
But it climbs up high.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_011/image/66D6C3095433388C8B34A544266C4DE7_0_940_1822_1414_2179.jpeg)