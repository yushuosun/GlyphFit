7.4 Linear Independence. Rank of a Matrix. Vector Space

# Linear Independence and Dependence of Vectors

Given any set of $m$ vectors $\mathbf{a}_{(1)}, \dots, \mathbf{a}_{(m)}$ (with the same
number of components), a linear combination of these
vectors is an expression of the form

$$c_{1}\mathbf{a}_{(1)},+c_{2}\mathbf{a}_{(2)},+\dots+c_{m}\mathbf{a}_{(m)}$$

where $c _ { 1 } , c _ { 2 } , \ldots , c _ { m }$ are any scalars.

Now consider the equation

(1)

$$c_{1}\mathbf{a}_{(1)},+c_{2}\mathbf{a}_{(2)},+\dots+c_{m}\mathbf{a}_{(m)}=\mathbf{0}$$

Clearly, this vector equation (1) holds if we choose all $c_j$ 's zero, because then it becomes $0 = 0$ .

If this is the only $m$ -tuple of scalars for which (1) holds, then our vectors $\mathbf{a}_{(1)}, \dots, \mathbf{a}_{(m)}$ are said to form a linearly independent set or, more briefly, we call them linearly independent.

Section 7.4 p57

Advanced Engineering Mathematics, $10/e$ by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.