# Gradients

• del C (or grad C)

$$\nabla C=\mathrm{i}\frac{\partial C}{\partial x}+\mathrm{j}\frac{\partial C}{\partial y}$$

• Diffusion (Fick's 1st Law):

$$\mathbf{J}=-D\nabla C$$