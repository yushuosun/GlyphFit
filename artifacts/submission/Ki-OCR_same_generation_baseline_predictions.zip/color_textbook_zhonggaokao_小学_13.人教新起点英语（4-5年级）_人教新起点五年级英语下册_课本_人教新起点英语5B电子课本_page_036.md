# B Do a survey.

Please interview your friends and find out what they would like to do on special days.

What's your favourite
special day?

My favourite special day is Teachers' Day. It's coming soon.

What would you like to do?

I'd like to buy some flowers and make a card for my teacher.

Would you like to
make a phone call
or send a message?

I'd like to call her.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_036/image/8E44A906BE7536E2BD4E858EE686B448_0_654_884_975_1223.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_036/image/8E44A906BE7536E2BD4E858EE686B448_0_1076_867_1414_1188.jpeg)

<table border="1"><tr><td>name</td><td>Bill</td><td></td><td></td></tr><tr><td>special day</td><td>Teachers&#x27; Day</td><td></td><td></td></tr><tr><td>things he/she wouldlike to do</td><td>buy some flowersmake a cardmake a phone call</td><td></td><td></td></tr></table>

# C  Let's write.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_036/image/8E44A906BE7536E2BD4E858EE686B448_0_233_1730_515_1988.jpeg)

What would you like to do on Spring Festival?