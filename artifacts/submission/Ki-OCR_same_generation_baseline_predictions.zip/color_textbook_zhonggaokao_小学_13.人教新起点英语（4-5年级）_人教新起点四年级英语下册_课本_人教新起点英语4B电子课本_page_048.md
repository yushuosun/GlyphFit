# Let's Spell

# A  Listen, point and repeat.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_157_311_390_589.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_224_692_333_764.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_219_809_330_877.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_543_311_763_587.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_558_640_679_788.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_566_806_704_870.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_889_329_1102_580.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_889_589_1059_867.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_1249_334_1431_580.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_1214_605_1471_867.jpeg)

# B  Read aloud. Then listen and check.

king wing  going strong wrong

# C  Listen and write.

1. I like ____.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_191_1387_530_1548.jpeg)

2. The bird has ____ ____ .

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_894_1132_1191_1358.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_1028_1501_1512_1688.jpeg)

3. ___________ is easier than ___________ .

# D  Listen and repeat.

My mother likes singing,
Singing happy songs.
My father likes reading,
Reading books all day long.
But I like running
And playing ping-pong!

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_048/image/97F7E225B221E7336F7A90B54FDA2534_0_859_1758_1446_2149.jpeg)