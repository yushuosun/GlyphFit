# Unit 4 Hobbies

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_043/image/7829E04EEE2D9D05A2681E4CD71BD575_0_0_0_1610_2336.jpeg)