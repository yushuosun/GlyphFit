7.3 Linear Systems of Equations. Gauss Elimination

At the end of the Gauss elimination (before the back
substitution), the row echelon form of the augmented
matrix will be

![](images/PPT_ch7_page_053/image/B874D7379D0ECA7DD48878F7BD0537EC_0_96_402_1290_1102.jpeg)

Here, and all entries in the blue triangle and blue rectangle are zero.

Section 7.3 p53

Advanced Engineering Mathematics, $10/e$ by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved