# Projection: Using Inner Products (I)

![](images/PPT_linear-algebra primer_page_007/image/D998693693A7420F6FBBA27607351D60_0_510_339_1384_955.jpeg)

Projection of $x$ along the direction $\mathbf{a}$ ( $\|\mathbf{a}\|=1$ ).

$$\mathbf{p}=\mathbf{a}(\mathbf{a}^{\mathrm{T}}\mathbf{x})$$

$$\left\|\mathbf{a}\right\|=\mathbf{a}^{\mathrm{T}}\mathbf{a}=1$$

Rensselaer Polytechnic Institute

Shivkumar Kalyanaraman

Google": "shiv rpi"