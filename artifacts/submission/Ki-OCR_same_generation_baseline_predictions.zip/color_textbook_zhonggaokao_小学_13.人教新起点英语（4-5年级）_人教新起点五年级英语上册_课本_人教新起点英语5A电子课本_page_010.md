# 3. Fill in the blanks.

(1) Joe often answers questions in English class. He is ____.   
(2) Joe is good at science. He is ____.   
(3) Sometimes Joe is ____. He likes reading and thinking.   
(4) He often says “Hello” and “Thank you" to everyone in the family. He is ____ .   
(5) He often helps Tom's family. He is ____.

# B Let's talk.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_010/image/6A407DF3605B1447E2A98E04F67FD9EA_0_125_774_1596_1305.jpeg)

# C Let's write.

Tom wants to introduce Joe to his classmates. Let's help him make a brief introduction.

• What is Joe like?   
• What is he good at?   
• What does he usually do?   
...

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_010/image/6A407DF3605B1447E2A98E04F67FD9EA_0_163_1756_305_1953.jpeg)

This is Joe. He is