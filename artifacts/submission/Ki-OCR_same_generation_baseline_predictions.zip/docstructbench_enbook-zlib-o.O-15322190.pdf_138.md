大型齿轮在机测量原理与技术

表6-5分离后齿面1齿廓偏差数据（右齿面）  

<table border="1"><tr><td>序号</td><td>齿轮分度转角/（°）</td><td>齿廓偏差/mm</td><td>序号</td><td>齿轮分度转角/（°）</td><td>齿廓偏差/mm</td></tr><tr><td>1</td><td>1</td><td>0.032</td><td>9</td><td>2.6</td><td>0.026</td></tr><tr><td>2</td><td>1.2</td><td>0.043</td><td>10</td><td>2.8</td><td>0.008</td></tr><tr><td>3</td><td>1.4</td><td>0.036</td><td>11</td><td>3.0</td><td>0.022</td></tr><tr><td>4</td><td>1.6</td><td>0.056</td><td>12</td><td>3.2</td><td>0.026</td></tr><tr><td>5</td><td>1.8</td><td>0.041</td><td>13</td><td>3.4</td><td>0.012</td></tr><tr><td>6</td><td>2.0</td><td>0.032</td><td>14</td><td>3.6</td><td>0.003</td></tr><tr><td>7</td><td>2.2</td><td>0.039</td><td>15</td><td>3.8</td><td>-0.016</td></tr><tr><td>8</td><td>2.4</td><td>0.021</td><td>16</td><td>4.0</td><td>-0.022</td></tr></table>

![](images/docstructbench_enbook-zlib-o.O-15322190.pdf_138/image/13AEFFE98C392686727E1BDCA99F3F8C_0_112_827_962_1395.jpeg)  
图 6-11 分离后齿面 1 齿廓偏差曲线图