# ESL programs at secondary school

![](images/PPT_The Right Moves_page_016/image/55EBD7F90113FC95CB92AE7E74D48952_0_996_0_1998_249.jpeg)

The framework of ESL programs in secondary school
differs significantly from the framework of ESL
programs in elementary school.