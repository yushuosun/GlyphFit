# HELP + NOUN + to V

![](images/PPT_session 10_page_028/image/BC32805B9CFFBC9E3DD7178BE39E1CE9_0_86_425_1922_1065.jpeg)

[help].[vv*] [n*] to [v*i]