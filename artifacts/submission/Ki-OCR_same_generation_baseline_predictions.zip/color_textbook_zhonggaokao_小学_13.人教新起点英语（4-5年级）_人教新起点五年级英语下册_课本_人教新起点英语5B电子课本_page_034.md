# B Choose, think and say.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_170_219_1543_678.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_176_692_674_1183.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_712_694_1195_1178.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_1228_694_1540_1178.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_176_1213_836_1539.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_879_1211_1540_1539.jpeg)

# C  Draw and write.

What would you like to do on Children's Day?

____
____
____
____

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语下册_课本_人教新起点英语5B电子课本_page_034/image/ED6F936FAD8DFCA0D4E399B04C8CA475_0_1104_1560_1537_1871.jpeg)