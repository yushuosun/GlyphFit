# HELP + PRON + V

![](images/PPT_session 10_page_022/image/967470EA9CE3B291ED909CFCCA813883_0_100_420_1876_1045.jpeg)

[help].[vv*] [p*] [v*i]