www.cheminform.wiley-vch.de

ChemInform

Germanium
I 4700

DOI: 10.1002/chin.201025015

25-015

# Mixed Cations and Structural Complexity in $ ( \mathrm{E u_{1-x} C a_{x}})_{4} \mathrm{I n}_{3} \mathrm{G e}_{4} $ and $ ( \mathrm{E u_{1-x} C a_{x}})_{3} \mathrm{I n}_{2} \mathrm{G e}_{3}- $ The First Two Members of the Homologous Series $ A_{2 [ \mathrm{n}+\mathrm{m}]} \mathrm{I n}_{2 \mathrm{n}+\mathrm{m}} \mathrm{G e}_{2 [ \mathrm{n}+\mathrm{m}]} $ (n, m = 1, 2, ... $ \infty $ ; A: Ca, Sr, Ba, Eu, or Yb). — $ \mathrm{E u_{1. 2 3} C a_{2. 7 7} I n_{3} G e_{4} ~( I)~}, $ $ \mathrm{E u_{2. 6 0} C a_{1. 4 0} I n_{3} G e_{4} ~( II)~}, $ $ \mathrm{E u_{0. 3 0} C a_{2. 7 0} I n_{2} G e_{3} ~( III)~}, $ and $ \mathrm{E u_{0. 6 6} C a_{2. 3 4} I n_{2} G e_{3} ~( IV)~} $ are synthesized from the elements in a molten In metal flux (960 $ ^{\circ} $ C, 20 h). The compounds are characterized by single crystal XRD, magnetic susceptibility measurements, and TB-LMTO band structure calculations. (I) and (II) crystallize in the space group C2/m with Z = 2, and (III) and (IV) in the space group Pnma with Z = 4. The polyanionic substructures of the compounds are based on $ \mathrm{I n G e_{4}} $ edge- sharing tetrahedra, $ \mathrm{G e_{2}} $ dimers, and bridging In atoms in a nearly square planar environment. — (YOU, T.-S.; TOBASH, P.H.; BOBEV $ ^{*} $ , S.; Inorg. Chem. 49 (2010) 4, 1773-1783; Dep. Chem. Biochem., Univ. Del., Newark, DE 19716, USA; Eng.) — W. Pewestorf

ChemInform 2010, 41, issue 25

$ \textcircled{c} $ 2010 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim