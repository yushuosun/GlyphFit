# Lesson 1

# A  Look, listen and repeat.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_044/image/2AC0B1F3BD5179EB1977DA1A65A589D0_0_107_322_1173_1078.jpeg)

# Shopping List

a knife   
an eraser   
a glue stick   
a ruler   
a schoolbag   
books √   
crayons $\surd$   
pens   
pencils   
scissors   
paper

# B Let's role-play.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_044/image/2AC0B1F3BD5179EB1977DA1A65A589D0_0_120_1199_1472_1786.jpeg)

# C  Let's write.

Do you have   
?Yes, we do.

Do you have   
? Sorry, we don't.