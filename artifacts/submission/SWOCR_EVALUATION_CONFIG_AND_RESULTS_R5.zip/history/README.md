# Original configuration

This file preserves the preparation-time configuration bytes. Use configs/swocr_ab.json for the release runtime settings and metadata/RELEASE_STATUS.json for completion status. The equivalence record verifies that all computational values match.
