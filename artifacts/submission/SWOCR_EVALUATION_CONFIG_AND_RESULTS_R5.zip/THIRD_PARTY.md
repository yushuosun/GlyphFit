# Software and document rights

SWOCR project source code and its original documentation are distributed under the [MIT License](LICENSE).

The TeleOCR source and model, renderer, evaluator and their dependencies are obtained separately under their own terms. Their pinned identities and upstream links are in [docs/DEPENDENCIES.md](https://github.com/yushuosun/SWOCR/blob/swocr-repro-r5/docs/DEPENDENCIES.md). The project context/runtime/journal helpers are included in `runtime_helpers/`.

The prediction archives contain model-produced transcriptions of benchmark documents, and the evidence files contain evaluation measurements. The project software license does not grant rights in underlying third-party document content, datasets, model weights or external software. No GT annotations, input images or model weights are bundled.
