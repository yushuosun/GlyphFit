M. Yoshikawa et al./Sensors and Actuators B 104 (2005) 282-288

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_362_187_661_475.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_676_182_985_475.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_1003_189_1309_475.jpeg)  
Fig. 5. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533.[ $ ( \mathrm{A c-D-T r p} ) / ( \mathrm{O D M A} ) \ =\ 0. 1 7, $ $ K_{\mathrm{S, a p p}}=5. 5 \times1 0^{3} \, \mathrm{m o l}^{-1} \, \mathrm{d m}^{3} ]. $

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_362_579_661_867.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_684_579_986_867.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_1006_581_1309_867.jpeg)  
Fig. 6. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAAN-533.[ $ ( \mathrm{A c-L-T r p} ) / ( \mathrm{O D M A} ) \ =\ 0. 1 7, $ $ K_{\mathrm{S, a p p}}=5. 5 \times1 0^{3} \, \mathrm{m o l}^{-1} \, \mathrm{d m}^{3} ]. $

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_353_967_661_1266.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_681_967_988_1266.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_1018_969_1317_1266.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_357_1370_661_1663.jpeg)  
Fig. 7. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533.[ $ ( \mathrm{A c-D-T r p} ) / ( \mathrm{O D M A} ) \ =\ 0. 2 1, $ $ K_{\mathrm{S, a p p}}=1. 2 0 \times1 0^{4} \, \mathrm{m o l}^{-1} \, \mathrm{d m}^{3} ]. $

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_681_1370_988_1661.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.05.025.pdf_5/image/C6A177D3D1AC5F68BB9CF4FEDABACE5B_0_1008_1370_1314_1661.jpeg)  
Fig. 8. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAAN-533.[ $ ( \mathrm{A c-L-T r p} ) / ( \mathrm{O D M A} ) \ =\ 0. 2 1, $ $ K_{\mathrm{S, a p p}}=1. 1 6 \times1 0^{4} \, \mathrm{m o l}^{-1} \, \mathrm{d m}^{3} ]. $

$$\Delta\theta=f[\mathrm{Ac-D-Trp}]_{\mathrm{m}}=fk_{\mathrm{A,app}}[\mathrm{Ac-D-Trp}]$$

and those for the L-isomer can be represented by the following equation:

$$\Delta\theta=f[\mathrm{Ac-L-Trp}]_{\mathrm{m}}$$

$$=f\left\{Pe_{\mathrm{A,app}}[\mathrm{Ac-L-Trp}]+\frac{K_{\mathrm{S,app}}[\mathrm{Site}]_{0}[\mathrm{Ac-L-Trp}]}{1+K_{\mathrm{S,app}}[\mathrm{Ac-L-Trp}]}\right\}$$

The apparent affinity constant between Ac-i-Trp and the formed chiral recognition site, which was constructed by the presence of i-isomer during the molecular imprinting process, was determined by the following procedure: the difference in the shift $(\Delta\theta)_{S}$ , between that for Ac-i-Trp, which was adsorbed not only on the chiral recognition site toward i-isomer but also on the non-specific region, and that for Ac-j-Trp, which was non-specifically adsorbed, was