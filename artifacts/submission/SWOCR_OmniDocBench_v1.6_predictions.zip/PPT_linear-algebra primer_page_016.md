# Determinant of a Matrix

Used for inversion

If det(A) = 0, then A has no inverse

$$A={\left[\begin{array}{ll}{a}&{b}\\ {c}&{d}\end{array}\right]}$$

$$\det(A)=ad-bc$$

$$A^{-1}={\frac{1}{ad-bc}}{\left[\begin{array}{ll}{d}&{-b}\\ {-c}&{a}\end{array}\right]}$$

http://www.euclideanspace.com/maths/algebra/matrix/functions/inverse/threeD/index.htm

Rensselaer Polytechnic Institute

Shivkumar Kalyanaraman

Google : "shiv rpi"