CHAPTER 5 Photoshop 商业调色技术

05 添加色阶 添加“色阶”图层，设置色阶参数，增强画面对比度。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63684042.pdf_172/image/BE28DB6EA5EEA11CA2BA92B8A604EE1B_0_131_276_728_956.jpeg)

06 盖印图层按下快捷键Ctrl+Shift+Alt+E，盖印可见图层。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63684042.pdf_172/image/BE28DB6EA5EEA11CA2BA92B8A604EE1B_0_759_278_1332_956.jpeg)

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63684042.pdf_172/image/BE28DB6EA5EEA11CA2BA92B8A604EE1B_0_128_991_728_1904.jpeg)

07 二次构图复制“盖印”图层，将复制的图层名称修改为“二次构图”。单击工具箱中的“矩形选框工具”按钮，在裙子底部绘制选区，按下快捷键Ctrl+T将选区内的图像进行变形，使裙子更长。变形完成后，按下快捷键Ctrl+Enter确定，继续按下快捷键Ctrl+D取消选区。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63684042.pdf_172/image/BE28DB6EA5EEA11CA2BA92B8A604EE1B_0_760_1313_1283_1573.jpeg)

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63684042.pdf_172/image/BE28DB6EA5EEA11CA2BA92B8A604EE1B_0_760_1592_1356_1904.jpeg)