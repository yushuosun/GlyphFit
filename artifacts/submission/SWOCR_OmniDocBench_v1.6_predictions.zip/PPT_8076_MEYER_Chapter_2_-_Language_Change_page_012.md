CAMBRIDGE

# Words in Modern and Older Indo-European Languages Equivalent to Modern English foot

<table border="1"><tr><td>Old English fótModern English footModern German FuβModern Dutch voetModern Norwegian fotModern Danish fodModern Swedish fot</td><td>Modern French piedModern Italian piedeModern Portuguese péModern Spanish pieSanskrit pātLatin pēsGreek peza</td></tr></table>

【紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 紧 r

CAMBRIDGE

UNIVERSITY PRESS