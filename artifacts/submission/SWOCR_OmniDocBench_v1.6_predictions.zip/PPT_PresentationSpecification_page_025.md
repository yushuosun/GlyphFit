# HOW TO PARTICIPATE?

# • Each STUDENT individually;

- Views other groups' video and live presentations;   
- Gives comments to other groups;   
- Rates other groups' work;

# • During tutorials;

- Each group should attend >= 66% tutorials;   
- Each group should present and lead a discussion session;   
• Each student shall participate in Q&A;

ENGG1000 Presentation Specification

5/21/2025