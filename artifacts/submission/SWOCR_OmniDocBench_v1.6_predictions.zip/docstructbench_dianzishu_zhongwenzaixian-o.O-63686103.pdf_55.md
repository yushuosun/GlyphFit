数字影音编辑与合成（Premiere Pro CS6 + After Effects CS6）

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63686103.pdf_55/image/F863B44DDCB84A466DAE6032A641A6D7_0_187_219_749_607.jpeg)  
图 3-11 拖长字幕和照片的时间到 5 秒

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63686103.pdf_55/image/F863B44DDCB84A466DAE6032A641A6D7_0_853_234_1247_607.jpeg)  
图 3-12 用快捷方式为照片添加转场“交叉叠化”

$\textcircled{7}$ 选中视频 2 轨，用同样的方法给字幕文件的开头和结尾都添加转场”交叉叠化”，如图3-13所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63686103.pdf_55/image/F863B44DDCB84A466DAE6032A641A6D7_0_181_775_713_1162.jpeg)  
图 3-13 用快捷方式为字幕添加转场“交叉叠化”

# ☐触类旁通

观察转场“交叉叠化”前的红色标记，这是其他转场特效都没有的。因为在制作过程中，“交叉叠化”是非常常用的一个转场，所以软件附加了快捷键 Ctrl+D 给它，以方便制作。在实际使用时，如果想把其他转场设为默认转场，可以用快捷键实现，也可以右击相应的转场，选择“设为默认转场”命令即可。

⑧ 拖动照片“2.jpg”到视频1轨，与轨  
道上的照片“1.jpg”无缝衔接，拖长时间到15秒；选择“字幕—新建字幕—基于模板”命令，在打开的“模板”窗口中选择字幕设计器预设下的“常规—小女孩—小女孩（标题）”命令，如图3-14和图3-15所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63686103.pdf_55/image/F863B44DDCB84A466DAE6032A641A6D7_0_217_1399_775_1789.jpeg)  
图 3-14 拖动照片素材并放长

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63686103.pdf_55/image/F863B44DDCB84A466DAE6032A641A6D7_0_846_1397_1289_1784.jpeg)  
图 3-15 选择字幕模板

$\textcircled{9}$ 更改模板文字，并删除条纹底图，然后在工具栏中选择矩形工具；在字幕上绘制矩形长条，修改填充颜色为白色，透明度为 60% ，如图 3-16 和图 3-17 所示。