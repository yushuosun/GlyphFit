www.cheminform.wiley-vch.de

ChemInform $ ^{®} $

Imidazole derivatives

R 0190

DOI: 10.1002/chin.201023119

23-119

Stereoselective Synthesis of 5-Substituted Pyrrolo[1,2-c]imidazol-3-ones: Access to Annulated Chiral Imidazol(in)ium Salts. — The title compounds are available in a 2-step procedure via diastereoselective or enantioselective lithiation. Followed by a $\mathrm{POC}1_{3}$ -induced salt formation, precatalysts of type (XII) can be prepared. — (METALLINOS $^{*}$ , C.; XU, S.; Org. Lett. 12 (2010) 1,76-79; Dep. Chem., Brock Univ., St. Catharines, Ont. L2S 3A1, Can.; Eng.) — R. Simon

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_117_388_249_521.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_258_406_416_468.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_426_390_570_521.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_595_406_840_486.jpeg)  
A): sBuLi, TMEDA, Et₂O, -78°C, [2 h]   
B): -78 -> +25℃, [16 h]

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_114_588_1043_760.jpeg)  
C): iPrLi, (-)-sparteine, Me-O-tBu, -78°C, [2 h]

![](images/docstructbench_llm-raw-scihub-o.O-chin.201023119.pdf_1/image/F015024716077390CCB96FDDA95F06E6_0_114_817_950_986.jpeg)

ChemInform 2010, 41, issue 23

2010 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim