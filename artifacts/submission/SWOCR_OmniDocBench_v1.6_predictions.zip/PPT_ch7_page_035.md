7.3 Linear Systems of Equations. Gauss Elimination

# Matrix Form of the Linear System (1). (continued)

We assume that the coefficients $a_{jk}$ are not all zero, so that $\mathbf{A}$
is not a zero matrix. Note that $\mathbf{x}$ has $n$ components, whereas
$\mathbf{b}$ has $m$ components. The matrix

$$\widetilde{\mathbf{A}}=\left[\begin{array}{ccc|c}a_{11}&\cdots&a_{1n}&b_1\\ \cdot&\cdots&\cdot&\cdot\\ \cdot&\cdots&\cdot&\cdot\\ a_{m1}&\cdots&a_{mn}&b_m\end{array}\right]$$

is called the augmented matrix of the system (1). The
dashed vertical line could be omitted, as we shall do later. It is merely a reminder that the last column of $\tilde{\mathbf{A}}$ did not
come from matrix $\mathbf{A}$ but came from vector $\mathbf{b}$ . Thus, we augmented the matrix $\mathbf{A}$ .

Section 7.3 p35

Advanced Engineering Mathematics, $10/e$ by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.