SOLUTIONS OF NONHOMOGENEOUS SYSTEMS

- Solution: Row operations on $[A \quad 0]$ produce

$$\left[\begin{array}{cccc}3&5&-4&7\\ -3&-2&4&-1\\ 6&1&-8&-4\\ \end{array}\right]\sim\left[\begin{array}{cccc}1&0&-\frac{4}{3}&-1\\ 0&1&0&2\\ 0&0&0&0\\ \end{array}\right],\begin{array}{}x_1-\frac{4}{3}x_3=-1\\ x_2=2\\0=0\end{array}$$

- Thus $x_{1} = - 1 + \frac { 4 } { 3 } x _{3} \,,\,x_{2} = 2$ ,and $x_{3}$ is free.

© 2016 Pearson Education, Inc.