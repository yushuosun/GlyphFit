# OTHER THINGS TO CONSIDER

○ Oral communication is different from written
communication   
- Keep it simple and focus on a few key points   
- Repeat key insights   
○Be sensitive to your audience   
- The same talk may need to be adjusted for a different audience   
○ Make the audience want to learn more   
○ Handling Q&A is as important as the formal talk itself

![](images/PPT_BaharMartonosi_page_008/image/5A250CC5084C4FE564A1BAB1B5DD5142_0_1778_1245_1908_1371.jpeg)