# 安妮如愿得到泡泡袖裙子

安妮在没来绿山墙农舍之前就非常渴望拥有一条属于自己的泡泡袖裙子。圣诞节来临，马修终于圆了她的梦。赶快拿起你的彩笔，为安妮画出这条她梦寐以求的新裙子吧！

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61511646.pdf_188/image/896492BC521AA7EECFE48E3225A31DC3_0_726_1142_898_1387.jpeg)