# KET 口语 Part 1演示

# place of origin/school 来自哪里/学校

Where do you come from?   
What do you study?   
Do you like your studies?

Do you study English at school?   
Do you like your school?   
What is your favourite subject?   
Why do you like it?

# KET 口语 Part 1演示

information about self 个人信息

Where do you go at the weekend?   
Who do you like spending time with?

# KET 口语 Part 1演示

tell me something about... 即兴问答

Where did you go last weekend?   
Tell me something about your future job   
Tell me something about your free time

![](images/color_textbook_zhonggaokao_小学_KET听说读写逐项突破_KET听说读写逐项突破之轻松搞定KET口语25分【10 褚连一】_第02讲第二课口语部分Part1详解_第二课口语部分Part1详解_page_002/image/96F8CCC5D4A9697F09877BD8EAA33278_0_1263_975_2236_1227.jpeg)  
PART 1