# Revision 2

# Let's Review

# A  Look, listen and choose.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_95_467_443_692.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_443_467_778_692.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_785_467_1124_692.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_1124_467_1464_692.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_102_743_457_998.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_467_750_800_1008.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_808_750_1145_998.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_1147_750_1461_1008.jpeg)

# B Choose and say.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_257_1139_495_1454.jpeg)

This is Ann. She likes delicious food.
She is good at cooking.   
She wants to be a cook in the future.

Name: Nancy   
Favourite things: animals and plants   
Good at: planting flowers   
Wants to be: a farmer

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_629_1485_732_1609.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_1257_1457_1358_1571.jpeg)

Name: Ann   
Favourite things: delicious food   
Good at: cooking   
Wants to be: a cook

Name: Sam   
Favourite things: cars   
Good at: driving bumper cars   
Wants to be: a driver

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_566_1831_664_1950.jpeg)

Name:   
Favourite things:   
Good at:   
Wants to be:

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语上册_课本_人教新起点英语4A电子课本_page_072/image/EC5E40D9F578DD9057549BD29AF350AB_0_1257_1829_1419_1995.jpeg)