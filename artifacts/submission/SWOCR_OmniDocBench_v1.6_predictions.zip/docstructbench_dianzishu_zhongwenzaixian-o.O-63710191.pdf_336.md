Chapter 10 International Direct Investment in China

Table 10.8 China’s Outward FDI Stock in Developed Countries (Regions), by the end of 2017   

<table border="1"><tr><td>Economy</td><td>Stock (Billions of US Dollars)</td><td>Share( %)</td></tr><tr><td>European Union</td><td>86.02</td><td>37.5</td></tr><tr><td>United States</td><td>67.38</td><td>29.4</td></tr><tr><td>Australia</td><td>36.18</td><td>15.8</td></tr><tr><td>Canada</td><td>10.94</td><td>4.8</td></tr><tr><td>Bermuda</td><td>8.59</td><td>3.8</td></tr><tr><td>Switzerland</td><td>8.11</td><td>3.5</td></tr><tr><td>Israel</td><td>4.15</td><td>1.8</td></tr><tr><td>Japan</td><td>3.20</td><td>1.4</td></tr><tr><td>New Zealand</td><td>2.49</td><td>1.1</td></tr><tr><td>Norway</td><td>2.08</td><td>0.9</td></tr><tr><td>Total</td><td>229.13</td><td>100.0</td></tr></table>

By the end of 2017, China's outward FDI stock in transition economies had reached \$27.49 billion, accounting for 1.5% of the total stock. In particular, Russia received \$13.87 billion, accounting for 50.5% of the total stock in the transition economies.

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-63710191.pdf_336/image/3F4BB61E26C7B6BF6BE8A5DCBCE00037_0_307_1073_824_1342.jpeg)  
Figure 10.18 Structure of China's Outward FDI Stock in Economies, by the end of 2017

Table 10.9 Top 20 Countries (Regions) as Destinations of China’s Outward FDI Stock, by the End of 2017   

<table border="1"><tr><td>No.</td><td>Country (Region)</td><td>Stock (Billions of US Dollars)</td><td>Share ( %)</td></tr><tr><td>1</td><td>Hong Kong China</td><td>981.27</td><td>54.2</td></tr><tr><td>2</td><td>Cayman Islands</td><td>249.68</td><td>13.8</td></tr><tr><td>3</td><td>British Virgin Islands</td><td>122.06</td><td>6.7</td></tr><tr><td>4</td><td>United States</td><td>67.38</td><td>3.7</td></tr><tr><td>5</td><td>Singapore</td><td>44.57</td><td>2.5</td></tr><tr><td>6</td><td>Australia</td><td>36.18</td><td>2.0</td></tr><tr><td>7</td><td>United Kingdom</td><td>20.32</td><td>1.1</td></tr></table>