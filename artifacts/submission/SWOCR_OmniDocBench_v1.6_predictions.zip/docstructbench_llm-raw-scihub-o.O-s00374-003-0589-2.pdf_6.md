![](images/docstructbench_llm-raw-scihub-o.O-s00374-003-0589-2.pdf_6/image/73EECD123060D00A36376E568D204DA3_0_598_135_1527_684.jpeg)  
Fig.3 Time course of the $ \mathrm{N_{2} O} $ fluxes from the control (0N) and $( \mathrm{N H_{4}})_{2} \mathrm{S O}_{4} $ (upper figure) and liquid fattening pig manure (traditional farming; lower figure) applied to soil at four application rates: 25 mg N kg $ ^{-1} $ (25N), 50 mg N kg $ ^{-1} $ (50N), 100 mg N kg $ ^{-1} $ (100N), 200 mg N kg $ ^{-1} $ (200N). At day 57 water was added (see Fig. 2)

![](images/docstructbench_llm-raw-scihub-o.O-s00374-003-0589-2.pdf_6/image/73EECD123060D00A36376E568D204DA3_0_598_702_1514_1254.jpeg)

Table 4 Total $ \mathrm{N_{2} O} $ emission after application of $ \mathrm{N H_{4} N O_{3}} $ and liquid pig manure (traditional farming) with different application techniques. For each column, different letters indicate statistically   
significant differences $ (\alpha=0.05) $ in log-transformed $ \mathrm{N_{2}O} $ emission between treatments   

<table border="1"><tr><td>Application method</td><td colspan="6">N$_2$O emission</td></tr><tr><td></td><td colspan="4">(mg N kg$^{-1}$)</td><td colspan="2">(％ of N applied)</td></tr><tr><td></td><td colspan="2">NH$_4$NO$_3$</td><td colspan="2">Liquid pig manure</td><td>NH$_4$NO$_3$</td><td>Liquid pig manure</td></tr><tr><td>Homogeneously mixed into soil</td><td>2.7</td><td>b</td><td>7.9</td><td>b</td><td>2.1</td><td>7.3</td></tr><tr><td>Surface applied</td><td>1.5</td><td>a</td><td>5.5</td><td>b</td><td>0.9</td><td>4.9</td></tr><tr><td>Placed at 5 cm depth</td><td>3.7</td><td>c</td><td>7.5</td><td>b</td><td>3.1</td><td>6.9</td></tr><tr><td>Placed at 10 cm depth</td><td>4.6</td><td>c</td><td>4.0</td><td>a</td><td>4.0</td><td>3.4</td></tr><tr><td>Placed in a row at 5 cm depth</td><td>4.9</td><td>c</td><td>12.9</td><td>c</td><td>4.3</td><td>12.3</td></tr></table>

# Discussion

Application of manure and fertilizer increases the amount of mineral N in soil and leads to higher emission of $\mathrm{N_{2} O}.$ Most research so far provides emissions for animal manure as such without discriminating between a range of manure qualities that are found in agricultural practice. The results reported here suggest that $\mathrm{N_{2} O}$ emission may

be quite different depending on manure species and related quality and on manure management and handling. Most of these effects can be attributed to specific manure or fertilizer characteristics. Even though our results are from laboratory incubations using a soil with relatively low organic matter content and low pH, they may form the basis for designed testing and verification methods in field conditions and eventually lead to the formulation of