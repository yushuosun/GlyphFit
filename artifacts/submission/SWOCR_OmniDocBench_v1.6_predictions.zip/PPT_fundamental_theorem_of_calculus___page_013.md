eg if $y = f(x) = 3x^2$ and $a=2$ and $b=4$

then Area A $= \int_{2}^{4} 3x^2 dx$

$$=\left[x^3\right]^4_2$$

$$=\left[4^3\right]-\left[2^3\right]$$

$$=64-8$$

$$=56\;\mathbf{units}^{2}$$

![](images/PPT_fundamental_theorem_of_calculus___page_013/image/FD0AF1DC1D10EF59F19EDAA058F88219_0_896_481_1662_1078.jpeg)