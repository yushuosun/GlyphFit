CAMBRIDGE

# Morphology (cont.)

Agglutinative languages—Meaning is expressed by
very complex internal structure. Turkish is a very
agglutinative language. The construction çayiçtik
means ‘We drank the tea’ (cay = ‘tea’; iç = ‘drink’; and
tik = ‘we/past’).

【证券】

CAMBRIDGE

UNIVERSITY PRESS