Formation of Methanesulfenyl Fluoride

FULL PAPER

own. Typical of the results are those afforded by B3LYP/6 $3 1+G^{*}$ methods; these indicate an equilibrium geometry which, like that of $\mathrm{H_{2} C=S \cdots H C l},$ is a bent planar one with the HF axis directed toward the S atom and subtending a C=S···H angle close to $9 0^{\circ}$ ,as shown in Figure 6. Such a

![](images/docstructbench_llm-raw-scihub-o.O-chem.200700118.pdf_7/image/C67E0B7EC391DC54DAEB8F47E3E2386F_0_274_392_654_629.jpeg)  
Figure 6. Molecular model of the $ \mathrm{H_{2} C S \cdots H F} $ ，complex optimized with the B3LYP/6-31+G* theoretical model.

structure and its dimensions tally with those deduced in the earlier theoretical studies. $^{[29,30]}$ The vibrational properties computed for the present model, together with the corresponding properties computed on a similar basis for the free subunits $\mathrm{H_{2} C=S}$ and HF, the experimental results both for the normal and perdeuterated forms of D and for the complex $\mathrm{H_{2} C=S\cdots H C l},$ are given as Supporting Information.

Where comparisons can be made, there is good agreement between the theoretical and experimental wavenumbers. Both the direction and magnitude of the wavenumber shifts found experimentally to be induced by complexation are reproduced by the calculations. For example, the experimental (HF) shift of $-435.3\,\mathrm{cm}^{-1}$ is matched theoretically by a shift of $-437.9\,\mathrm{cm}^{-1}.$ . Small blue shifts of the fundamentals that could be observed for the $\mathrm{H_{2} C=S~s}$ subunit are also anticipated satisfactorily by the calculations. Low intensity in terms of IR absorption, masking by more intense absorptions of other species, and wavenumbers falling below the minimum threshold of the present measurements are then explanations sufficient to account for the fundamentals of $\mathrm{H_{2} C= S\cdots HF}$ and $\mathrm{D_{2} C=S\cdots DF}$ that escaped detection. Despite these omissions, though, we have little doubt that D has thus been identified correctly.

# Conclusions

The matrix photochemistry of methyl thiofluoroformate, $\mathrm{FC(O)}\mathrm{SCH}_{3}$ , follows closely the precedents set by the corresponding thiochloroformate, $\mathrm{ClC(O)}\mathrm{SCH}_{3}.$ $^{[9]}$ The various reaction channels have been charted by characterization of the photoproducts by their IR spectra and by monitoring the behavior of the IR absorptions as a function of photolysis time. The conclusions have been endorsed by studying the effects of perdeuteration of the parent compound and carrying out quantum chemical calculations on the putative products.

The photolytic interconversion of the two rotamers of $\mathrm{FC(O)}\mathrm{SCH}_{3}$ is the first process observed on broadband UVvisible irradiation of the matrix-isolated molecule, behavior

made familiar by analogous studies of other sulfenyl carbonyl compounds, for example, $\mathrm{C l C ( O ) S C H_{3},}$ $^{[9]}$ FC(O)SCl， $^{[12]}$ FC(O)SBr. $^{[4]}$ and ClC(O)SBr. $^{[11]}$ The unambiguous identification of IR absorptions due to the less stable anti rotamer allows us to conclude that the vapor is composed of approximately 98 % of the syn form and 2 % of the anti form at ambient temperatures, in good agreement with the forecasts of quantum chemical calculations. Both forms of $\mathrm{FC(O)}\mathrm{SCH}_{3}$ then photodecompose. The main reaction channel involves the elimination of CO with the formation of the hitherto elusive sulfenyl fluoride $\mathrm{CH}_{3}\mathrm{SF}$ , thus emulating similar photochemical processes starting from $\mathrm{C l C ( O ) S C H_{3},}$ $^{[9]}$ FC(O)SCl. $^{[3]}$ FC(O)SBr. $^{[4]}$ and ClC(O)SBr. $^{[11]}$

In a final step, continued UV-visible irradiation brings about a tautomeric change in $\mathrm{C H_{3} S F},$ with detachment of a hydrogen atom from the methyl group to form HF and thioformaldehyde, $\mathrm{H_{2} C=S},$ ,which together form the complex $\mathrm{H_{2} C=S\cdots HF}.$

Scheme 2 summarizes these photochemical events. In addition,there are secondary reactions involving, for example, the elimination of OCS, together presumably with $\mathrm{C H_{3} F}$ although this could not be detected, as well as the formation of loosely bound CO complexes.

![](images/docstructbench_llm-raw-scihub-o.O-chem.200700118.pdf_7/image/C67E0B7EC391DC54DAEB8F47E3E2386F_0_854_987_1515_1688.jpeg)  
Scheme 2. Outline of the photochemical reactions of $ \mathrm{FC(O)}\mathrm{SCH}_{3} $ isolated in a solid Ar matrix.

# Experimental and Computational Procedures

$\mathrm{FC(O)}\mathrm{SCH}_{3}$  was prepared by the reaction of $\mathrm{ClC(O)}\mathrm{SCH}_{3}$ with TIF (both from Aldrich) at ambient temperature, $^{[7]}$  and subsequently purified by repeated trap-to-trap condensation under vacuum. The purity of the compound was checked by reference to the IR spectrum of the vapor and to the $^{1}\mathrm{H},$ $^{13}\mathrm{C}$ , and $^{19}\mathrm{F}$ NMR spectra of the liquid. $^{[8]}$ The perdeuterated compound $\mathrm{FC(O)}\mathrm{SCD}_{3}$  was prepared for the first time by the corre-

Chem.Eur. J.2007,13,8185-8192

$ \textcircled{c} $ 2007 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim

www.chemeurj.org