国海证券 SEALAND SECURITIES

证券研究报告

<table border="1"><tr><td>预测指标</td><td>2022A</td><td>2023E</td><td>2024E</td><td>2025E</td></tr><tr><td>营业收入（百万元）</td><td>8369</td><td>19212</td><td>25711</td><td>26621</td></tr><tr><td>增长率(%)</td><td>-23</td><td>130</td><td>34</td><td>4</td></tr><tr><td>归母净利润（百万元）</td><td>-3036</td><td>1740</td><td>3862</td><td>3357</td></tr><tr><td>增长率(%)</td><td>-7862</td><td>157</td><td>122</td><td>-13</td></tr><tr><td>摊薄每股收益（元）</td><td>-3.10</td><td>1.78</td><td>3.95</td><td>3.43</td></tr><tr><td>ROE(%)</td><td>-22</td><td>11</td><td>20</td><td>15</td></tr><tr><td>P/E</td><td>一</td><td>35.08</td><td>15.81</td><td>18.19</td></tr><tr><td>P/B</td><td>4.59</td><td>3.96</td><td>3.16</td><td>2.70</td></tr><tr><td>P/S</td><td>7.51</td><td>3.18</td><td>2.37</td><td>2.29</td></tr><tr><td>EV/EBITDA</td><td>-166.25</td><td>12.60</td><td>7.85</td><td>8.44</td></tr></table>

资料来源：Wind资讯、国海证券研究所

请务必阅读正文后免责条款部分