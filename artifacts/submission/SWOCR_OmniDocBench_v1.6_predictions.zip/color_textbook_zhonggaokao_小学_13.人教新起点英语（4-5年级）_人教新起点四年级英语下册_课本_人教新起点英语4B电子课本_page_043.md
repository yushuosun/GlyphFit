# Unit 4 Hobbies

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_043/image/E1206CBAA6F901BF7A6DC2F663AF7225_0_0_0_1610_2336.jpeg)