7.9 Vector Spaces, Inner Product

Spaces, Linear Transformations Optional

# Linear Transformations (continued)

If $\mathbf{A}$ in (11) is square, $n \times n$ , then (11) maps $R^n$ into $R^n$ . If this
$\mathbf{A}$ is nonsingular, so that $\mathbf{A}^{-1}$ exists (see Sec. 7.8), then
multiplication of (11) by $\mathbf{A}^{-1}$ from the left and use of
$\mathbf{A}^{-1}\mathbf{A} = \mathbf{I}$ gives the inverse transformation

$$\tag{14}\mathbf{x}=\mathbf{A}^{-1}\mathbf{y}.$$

It maps every $\mathbf{y} = \mathbf{y}_0$ onto that $\mathbf{x}$ , which by (11) is mapped
onto $\mathbf{y}_0$ . The inverse of a linear transformation is itself linear,
because it is given by a matrix, as (14) shows.

Section 7.9 p136

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.