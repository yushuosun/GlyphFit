↑

教材全解 /+/二年级英语（第一学期）

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_513_165_561_226.jpeg)

# 小试牛刀

Read and judge（判断下列句子是否符合所给的情景，用（或（表示）

○

1. 你点着自己的鼻子，你说：This is my ear.

○

2. 你指着对方的鼻子，你说：This is your nose.

○

3. 你有一双大眼睛，你说：My eyes are big.

○

4. 指着自己的红头发，你说：Look. My hair is yellow.

○

5. 告诉别人，你喜欢苹果，你说：You like apples.

# Learn the letters→见教材 P25

<table border="1"><tr><td>字母</td><td>音标</td><td colspan="8">运用</td></tr><tr><td>Kk</td><td>/k/</td><td colspan="8">$\mathrm{\underline{k}ite \quad \underline{K}itty \quad \underline{k}iss \quad mil\underline{k} \quad loo\underline{k} \quad blac\underline{k} \quad stic\underline{k} \quad duc\underline{k} \quad soc\underline{k}}$</td></tr><tr><td>Ll</td><td>/l/</td><td colspan="8">$\mathrm{\underline{l}ion \quad \underline{l}ight \quad \underline{l}eg \quad \underline{l}emon \quad \underline{l}isten \quad \underline{l}ove\underline{l}y \quad \underline{l}ive \quad \underline{l}ike \quad \underline{l}et}$</td></tr></table>

Look! $\downarrow$ A lion! $\downarrow$ 看！一头狮子！

Look! $\downarrow$ A kite! $\downarrow$ 看！一只风筝！

Look! $\downarrow$ A lion and a kite. $\downarrow$ 看！一头狮子和一只风筝。

A big lion and a small kite. $\downarrow$ 一头大狮子和一只小风筝。

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_516_1079_558_1137.jpeg)

# 词汇清单

<table border="1"><tr><td>单词</td><td>音标</td><td>词性</td><td>词义</td><td>运用</td></tr><tr><td>kite</td><td>/kait/</td><td>n.</td><td>风筝</td><td>I can fly a kite. 我会放风筝。</td></tr><tr><td>lion</td><td>/&#x27;laiən/</td><td>n.</td><td>狮子</td><td>Look at the lion. It&#x27;s so big. 看这头狮子,它好大。</td></tr></table>

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_505_1384_568_1441.jpeg)

# 互动学习

# 重点讲解·吃透教材

# 认读和书写：Kk 和 LI 并掌握其基本读音

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_250_1556_476_1648.jpeg)

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_518_1556_745_1648.jpeg)

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_250_1667_476_1759.jpeg)

![](images/color_textbook_教材全解1+1二年级上册英语上海牛津版_page_058/image/A7B9E5E5C2E666C3DB4755EA07385286_0_518_1667_745_1759.jpeg)

# 指点迷津·提升能力

字母K的发音是清辅音 /k/，声带不振动。发音时舌后部隆起紧贴软腭，憋住气，然后突然分开，气流送出口腔，形成爆破音。

字母L的发音是/ $/$ ，舌端齿

关注微信公众号“教辅资料站”获取更多学习资料