# Academic English

![](images/PPT_The Right Moves_page_010/image/9AD294101C106EC8466193EDFAE80E12_0_996_0_1998_249.jpeg)

# Academic English takes 5 -7 years to acquire.

Academic English is more difficult to acquire and
takes much longer, often five or more years. ELLs
are working hard to catch up to a moving target –
they are learning the language of instruction at the
same time as they are learning the grade curriculum.