![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61571884.pdf_94/image/C19FFB5575136291828FE764031F1D08_0_178_97_648_475.jpeg)  
图 6-19 绘制辅助线和点

在顶视图中以刚刚绘制的水平线为直径，捕捉其两个端点绘制一个椭圆，如图 6-20所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61571884.pdf_94/image/C19FFB5575136291828FE764031F1D08_0_188_746_630_1151.jpeg)  
图 6-20 绘制椭圆

# 3. 绘制曲线

在左视图中捕捉点和椭圆的四分点，参考头盔背景图绘制头盔两侧的两条曲线，并适当调整使其光滑，如图 6-21 所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61571884.pdf_94/image/C19FFB5575136291828FE764031F1D08_0_185_1507_636_1862.jpeg)  
图 6-21 绘制两侧曲线

# 4. 双轨扫掠

执行 “建立曲面” 工具箱中的 “双轨扫掠” 命令，以点和椭圆为路径，以两条曲线为断面曲线，在打开的 “双轨扫掠选项” 对话框中，直接单击 “确定”，完成头盔主体曲面的创建，如图 6-22 所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61571884.pdf_94/image/C19FFB5575136291828FE764031F1D08_0_736_447_1275_744.jpeg)  
图 6-22 双轨扫掠

# 5. 绘制前部侧面轮廓线

执行 “控制点曲线” 命令，参考背景图，在左视图中绘制头盔侧面轮廓线，如图 6-23 所示。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61571884.pdf_94/image/C19FFB5575136291828FE764031F1D08_0_741_1097_1272_1532.jpeg)  
图 6-23 绘制前部侧面轮廓线

# 6. 分割前部曲面

执行左侧工具条上的“分割”命令，选择头盔曲面作为“要分割的物件”，选择刚绘制的曲线作为“切割用物件”，进行曲面分割，分割后的效果如图6-24所示。此时可通过执