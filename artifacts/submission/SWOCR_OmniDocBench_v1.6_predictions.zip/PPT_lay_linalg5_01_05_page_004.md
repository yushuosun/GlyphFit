# HOMOGENEOUS LINEAR SYSTEMS

$$\left[\begin{array}{cccc}3&5&-4&0\\ -3&-2&4&0\\6&1&-8&0\end{array}\right]{\sim}\left[\begin{array}{cccc}3&5&-4&0\\ 0&3&0&0\\0&-9&0&0\end{array}\right]{\sim}\left[\begin{array}{cccc}3&5&-4&0\\ 0&3&0&0\\0&0&0&0\end{array}\right]$$

■ Since $x_3$ is a free variable, $Ax = 0$ has nontrivial solutions (one for each choice of $x_3$ .)

■ Continue the row reduction of $[A \quad 0]$ to reduced

echelon form:

$$\left[\begin{array}{cccc}1&0&-\frac{4}{3}&0\\ 0&1&0&0\\0&0&0&0\end{array}\right]$$

$$x_{1}-\frac{4}{3}x_{3}=0$$

$$x_{2}=0$$

$$0=0$$

© 2016 Pearson Education, Inc.