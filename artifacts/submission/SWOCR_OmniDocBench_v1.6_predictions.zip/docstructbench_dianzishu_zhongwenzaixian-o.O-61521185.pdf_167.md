第四章 主食类

X

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61521185.pdf_167/image/EF04144E0FD7F863F20BAECDF7E0F17C_0_216_330_295_404.jpeg)

# 葱油面

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61521185.pdf_167/image/EF04144E0FD7F863F20BAECDF7E0F17C_0_765_294_1088_606.jpeg)

# 材料成分

主料：香葱 500g ，大葱 500g ，紫葱头 500g ，切面 （细） 5kg；

辅料：水 300g，油菜 500g，食用油 500g；

调料：酱油 1kg。

# 制作过程

香葱切段，大葱、葱头切丝，油菜切开备用；葱油制作：锅内放油烧至三成热，将香葱、大葱、葱头入锅小火熬制20分钟后加酱油、水，开锅10分钟盛出；锅中煮面条的同时放一个小油菜，煮熟后浇上葱油、撒上香葱粒即可（原料按35碗计算）。

# 工艺技巧

面条要细；熬油温度不宜太高。

# 品质特点

柔韧爽滑，葱香可口。

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61521185.pdf_167/image/EF04144E0FD7F863F20BAECDF7E0F17C_0_838_731_1182_965.jpeg)  
原材料图

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61521185.pdf_167/image/EF04144E0FD7F863F20BAECDF7E0F17C_0_838_1084_1182_1317.jpeg)  
半成品图

王广勇 提供