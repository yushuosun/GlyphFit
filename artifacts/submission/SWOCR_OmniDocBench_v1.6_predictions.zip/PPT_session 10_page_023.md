# HELP + NOUN + V

![](images/PPT_session 10_page_023/image/92D48C0007FC2077E47C4CFF1F427E2F_0_160_451_1802_1021.jpeg)

[help].[vv*] [n*] [v*i]