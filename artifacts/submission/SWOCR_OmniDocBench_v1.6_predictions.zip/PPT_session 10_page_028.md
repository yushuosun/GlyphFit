# HELP + NOUN + to V

![](images/PPT_session 10_page_028/image/FE3F6CB9788B8ACC0DF6D979019DEB63_0_86_425_1922_1065.jpeg)

[help].[vv*] [n*] to [v*i]