# Thank You!

![](images/PPT_LEP power point presentation-English-FINAL-10-31-07_page_015/image/F41476D8AB1ACEB187A883FC5219ABC1_0_662_562_1230_1252.jpeg)

“...promoting the well-being and safety of our children, families and communities....”