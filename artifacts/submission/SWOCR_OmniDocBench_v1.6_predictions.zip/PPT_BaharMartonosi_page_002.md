# WHY BOTHER GIVING A GOOD TALK?

○ First impressions matter!

○ There's no point doing good work if others don't know about it or can't understand what you did.

Good practice for a teaching career! Good practice for any career!

![](images/PPT_BaharMartonosi_page_002/image/E98CBB768C0B1B7DE30AB745F37DD192_0_22_807_174_909.jpeg)

Helps you sort out what you've done, and understand it better yourself.