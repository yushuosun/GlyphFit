# Lesson 1

# A  Listen and match.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_219_299_413_542.jpeg)  
Peter

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_481_346_740_521.jpeg)  
Helen

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_910_320_1180_533.jpeg)  
Tom

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_1249_376_1353_533.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_1385_306_1525_533.jpeg)  
Mary

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_171_685_456_909.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_537_678_740_921.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_907_685_1233_907.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_1244_680_1557_905.jpeg)

# B  Think and say.

Let's talk about our classmates.

Lily is cute.

And she's friendly, too.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_006/image/C14899CB5A2081976634D66B7A6BD3F1_0_436_1162_1284_1553.jpeg)

<table border="1"><tr><td></td><td>clever</td><td>careless</td><td>quiet</td><td>friendly</td><td>popular</td><td>active</td><td>polite</td><td>cute</td><td>helpful</td></tr><tr><td>Lily</td><td></td><td></td><td></td><td>✓</td><td></td><td></td><td></td><td>✓</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

# C Let's write.

Lily is friendly and ____.

____ is ____ and ____.

____ is ____ and ____.