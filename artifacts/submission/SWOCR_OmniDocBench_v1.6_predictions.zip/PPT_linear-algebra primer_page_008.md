# Bases & Orthonormal Bases

Basis (or axes): frame of reference

![](images/PPT_linear-algebra primer_page_008/image/5F7D595A561C097716763805195110C3_0_350_411_1000_754.jpeg)

![](images/PPT_linear-algebra primer_page_008/image/5F7D595A561C097716763805195110C3_0_1238_346_1828_799.jpeg)

Basis: a space is totally defined by a set of vectors – any point is a linear combination of the basis

Ortho-Normal: orthogonal + normal

[Sneak peek:

Orthogonal: dot product is zero

Normal: magnitude is one ]

Rensselaer Polytechnic Institute

$$x={\left[\begin{array}{lll}{1}&{0}&{0}\end{array}\right]}^{T}\qquad\quad x\cdot y=0$$

$$y=\left[\begin{array}{ccc}0&1&0\end{array}\right]^T\qquad\quad x\cdot z=0$$

$$z=\left[0\quad 0\quad 1\right]^T\quad y\cdot z=0$$

Shivkumar Kalyanaraman

Google: "shiv rpi"