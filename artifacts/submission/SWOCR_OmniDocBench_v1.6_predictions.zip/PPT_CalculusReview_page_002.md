# Slope

• Slope = rise/run   
• $= \Delta y / \Delta x$   
• $= ( y _ { 2 } - y _ { 1 } ) / ( x _ { 2 } - x _ { 1 } )$   
- Order of points 1 and 2 not critical, but keeping them together is   
- Points may lie in any quadrant: slope will work out   
- Leibniz notation for derivative based on $\Delta y / \Delta x$ ; the derivative is written $dy / dx$

![](images/PPT_CalculusReview_page_002/image/3F5B0971B508831D4F4D20CA96B19192_0_1052_363_1950_1260.jpeg)