# Activation energy

• Molecules must be activated before they can undergo a reaction   
- Reactants must absorb enough energy from surroundings to destabilize chemical bonds (energy of activation)   
- Transition state   
– Intermediate stage in
reaction where the
reactant molecule is
strained or distorted but
the reaction has not yet
occurred

![](images/PPT_Catalysis.ppt_page_003/image/E27FFCBDF9CE7C98B2B8D9BCE69B1615_0_944_537_1914_1066.jpeg)