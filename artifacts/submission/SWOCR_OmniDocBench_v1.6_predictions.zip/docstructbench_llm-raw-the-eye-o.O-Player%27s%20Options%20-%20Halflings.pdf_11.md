TABLE 5: WEAPONS   

<table border="1"><tr><td>Weapon</td><td>Cost</td><td>Dmg (S)</td><td>Dmg (M)</td><td>Critical</td><td>Range</td><td>Weight</td><td>Type</td><td>Special</td></tr><tr><td>Slingshot, Halfling</td><td>15 gp</td><td>1d4</td><td>1d6</td><td>19-20/x2</td><td>75ft.</td><td>1lb.</td><td>B</td><td>-</td></tr><tr><td>Bullets, Slingshot (10)</td><td>1 sp</td><td>-</td><td>-</td><td>-</td><td>-</td><td>5lbs.</td><td>-</td><td>-</td></tr><tr><td>Sling-staff, Halfling</td><td>25 gp</td><td>2d3/1d6</td><td>2d4/1d8</td><td>19-20/x2</td><td>50ft.</td><td>2lbs.</td><td>B/B</td><td>-</td></tr><tr><td>Bullets,Sling-staff(10)</td><td>1sp</td><td>-</td><td>-</td><td>-</td><td>-</td><td>5lbs.</td><td>-</td><td>-</td></tr></table>

TABLE 6: MUNDANE GEAR   

<table border="1"><tr><td>Item</td><td>Cost</td><td>Weight</td></tr><tr><td>Halfling Blueberry Ale</td><td>7 cp/5 sp/2 gp</td><td>-</td></tr><tr><td>(sold by pint bottle, 1-gallon keg, and 5-gallon keg)</td><td></td><td></td></tr><tr><td>Halfling Cloak</td><td>25 gp (50 gp)</td><td>2 lbs. (3 lbs.)</td></tr><tr><td>Halfling Pouch Belt</td><td>10 gp (15 gp)</td><td>1 lb. (1½lbs.)</td></tr><tr><td>Halfling Tobacco</td><td>7 sp</td><td>1 lb.</td></tr><tr><td>Halfling Tri-flute</td><td>9 gp</td><td>-</td></tr></table>

allows a traveler to walk or ride in the rain or snow without getting soaked to the bone. Wearers of these cloaks benefit from condition similar to that provided by endure elements, though it only protects from cold brought on specifically due to exposure to rain and/or snow.

Occasionally, halflings may make these cloaks for the "big folk". For anyone larger than a halfling, use the cost and weight in parenthesis.

Halfling Pouch Belt: The halfling pouch belt is a sturdy but supple leather belt with six leather pouches sewn to it. Each pouch closes via a brass button, and each can hold about as much as a standard halflingsized belt pouch. The organization the pouches afford means items may be retrieved quickly. One item per round may be accessed as a swift action. Accessing any other items from the pouches – or placing them in the pouches – takes a normal move action.

Occasionally, halflings may make these belts for the "big folk". For anyone larger than a halfling, use the cost and weight in parenthesis.

![](images/docstructbench_llm-raw-the-eye-o.O-Player%27s%20Options%20-%20Halflings.pdf_11/image/0D1ACFE2FF371BF11FB026C28987950C_0_144_1529_513_2043.jpeg)

Halfling Tobacco: Also known as pipeweed, halfling leaf or sometimes just leaf, halfling tobacco has been perfected over many decades to be very mild, very sweet and slow burning.

Halfling Tri-Flute: The halfling tri-flute may be a variant or descendant   
of the aulos or panpipe, or it may be a unique creation altogether. It consists of three short wooden

flutes, each of varying lengths, connected with leather bands. There are four fingerholes on the longest pipe three on the shortest and none on the middle pipe. A single mouthpiece connects to all three pipes.

![](images/docstructbench_llm-raw-the-eye-o.O-Player%27s%20Options%20-%20Halflings.pdf_11/image/0D1ACFE2FF371BF11FB026C28987950C_0_867_1304_1550_2039.jpeg)