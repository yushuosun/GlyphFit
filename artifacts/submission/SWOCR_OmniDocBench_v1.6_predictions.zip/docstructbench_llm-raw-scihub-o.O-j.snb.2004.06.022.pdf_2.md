W.P. Jakubik et al./Sensors and Actuators B 105 (2005) 340-345

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.06.022.pdf_2/image/A1BC6261255A859356AD1F093D07B11D_0_254_187_646_361.jpeg)  
Fig. 1. Real structure consisting of three thin layers: silver (for electric contact), metal-free phthalocyanine and palladium fabricated on an alundum substrate.

The main goal of this paper is to investigate the electric resistance of a layered phthalocyanine and palladium (Pc + Pd) structure under the influence of various hydrogen concentrations in nitrogen and air. We show that during the

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.06.022.pdf_2/image/A1BC6261255A859356AD1F093D07B11D_0_1023_187_1333_361.jpeg)  
Fig. 2. A scheme of resistance measurements in the two-point method. Changes in resistance were monitored by an automatic data acquisition unit Agilent 34970A for various hydrogen concentrations in nitrogen or in air.

interaction of hydrogen with bilayer structures metal-free phthalocyanine and palladium there occurs a strong change in the resistance of these structures. This would correspond to an acousto-electric effect in the SAW sensor system

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.06.022.pdf_2/image/A1BC6261255A859356AD1F093D07B11D_0_332_698_1292_1319.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-j.snb.2004.06.022.pdf_2/image/A1BC6261255A859356AD1F093D07B11D_0_330_1352_1295_1971.jpeg)  
Fig. 3. Changes in the resistance of structures with two different thicknesses of metal-free phthalocyanine (55 nm circle - left axis, and 80 nm triangle right axis) interaction in nitrogen, (a) at lower hydrogen concentrations 0.5-2.5% and (b) at higher concentrations 2.5-4%.