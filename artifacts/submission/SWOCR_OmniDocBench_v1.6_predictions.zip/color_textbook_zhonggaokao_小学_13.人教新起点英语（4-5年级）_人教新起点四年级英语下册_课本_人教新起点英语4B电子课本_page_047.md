# Lesson 3

# A  Read and write.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_047/image/8E0E3899B2B10484AF125DC49A04994A_0_583_222_671_313.jpeg)

This is my family's hobby book. I like
collecting stamps. I have over 200

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_047/image/8E0E3899B2B10484AF125DC49A04994A_0_1155_264_1350_463.jpeg)

stamps. I also like skateboarding. I think it is very cool.My mother likes drawing.She is really good at it.My father likes fishing.He often goes fishing but never catches any fish.My cat likes eating fish.She often goes with my father,but she never gets any fish!

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点四年级英语下册_课本_人教新起点英语4B电子课本_page_047/image/8E0E3899B2B10484AF125DC49A04994A_0_87_884_1462_1232.jpeg)

# B  Read again and write.

Bob likes

His mother likes

His father likes

His cat likes

I like

My