![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_133_137_825_606.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_838_135_1536_606.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_133_610_825_1105.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_838_610_1536_1101.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_127_1114_823_1607.jpeg)  
Fig. 2a–e. Bolus profiles from rat ureter during low diuresis. Two seconds of recording time were evaluated reading every other frame. From the total of 30 profiles (Fig. 3), a selection of 7 is shown in the figure. Digitized grey levels (y-axis) are plotted against points or pixels in the ureter (x-axis) beginning with the proximal ureter at x = 0. The high luminance readings all along the ureter in a and e indicate the absence of dye before and after a bolus transit. Notice the collection of low grey levels moving from the left (b) to the right part of the curve (d) representing an urine bolus travelling from the proximal to the distal ureter. (Magnification 16×, 1 mm = 18 points or pixels)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_123_1627_801_1999.jpeg)

![](images/docstructbench_llm-raw-scihub-o.O-bf00326833.pdf_3/image/BA7E6A376BEB7D644858A44543BB289A_0_851_1424_1521_1821.jpeg)  
Fig. 4. Time-distance diagram of bolus profiles. X-axis: time in seconds (30 frames = 2 sec); y-axis: length along ureter in pixels, beginning in the upper ureter (0) down to the lower third (180). The black shaded curve shows the position and length of the bolus at any given point of time. The upper slope indicates the velocity of the trailing end of the bolus (determined by the contraction ring); the lower slope indicates the velocity of the leading end of the bolus. In this example both velocities are almost identical   
Fig. 3. Thirty bolus profiles in a three-dimensional presentation