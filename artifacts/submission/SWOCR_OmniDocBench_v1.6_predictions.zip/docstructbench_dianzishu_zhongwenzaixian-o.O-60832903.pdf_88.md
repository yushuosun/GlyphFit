"Who are you?" said Lucie. "Have you seen my pocket-handkins?"

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-60832903.pdf_88/image/680C47851DB6CD2A9205F3AB4C471BF2_0_83_271_446_670.jpeg)

The little person made a bob-curtsey—"Oh, yes, if you please'm; my name is Mrs. Tiggy-winkle; oh, yes if you please'm, I'm an excellent clear-starcher!" And she took something out of a clothes-basket, and spread it on the ironing-blanket.

“What's that thing?” said Lucie—"that's not my pocket-handkin?"

"Oh no, if you please'm; that's a little scarlet waistcoat belonging to Cock Robin!"

And she ironed it and folded it, and put it on one side.

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-60832903.pdf_88/image/680C47851DB6CD2A9205F3AB4C471BF2_0_529_859_868_1228.jpeg)