# Lesson 1

# A  Listen and match.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_128_299_350_502.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_466_301_649_502.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_765_304_942_507.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_1056_283_1214_505.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_1333_315_1472_500.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_79_626_340_813.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_381_673_657_846.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_702_629_971_813.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_1014_661_1269_832.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_1329_626_1588_816.jpeg)

# B Let's talk.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_060/image/0DB16ACA52EDD5B279B44010E1F3D6E7_0_97_975_1614_1648.jpeg)

# C Let's write.

My favourite TV shows are _______________.

My grandmother's favourite TV shows are _______________.

My grandfather's favourite TV shows are ______________.

My father's favourite TV shows are _______________.

My mother's favourite TV shows are _______________.