CNAS-GL08: 2006

$$P_{x}=\frac{w}{t}\qquad w=\frac{n}{N}\times3.6\times10^{6}瓦秒$$

$P_{x}$ ——被测功率 w;
$w$ ——电度表累积测得电能；
$N$ ——电度表每千瓦时盘转动数；
$n$ ——电度表的转数 转；
$t$ ——测量时间 s

# 3 方差与传播系数

$${u}^{2}\left({P}_{x}\right)={\left(\frac{\partial f}{\partial w}\right)}^{2}{u}^{2}\left(w\right)+{\left(\frac{\partial f}{\partial t}\right)}^{2}{u}^{2}\left(t\right)={c}^{2}\left(w\right){u}^{2}\left(w\right)+{c}^{2}\left(t\right){u}^{2}\left(t\right)$$

$$c(w)=\frac{1}{t}$$

$$c(t)=-\frac{w}{t^{2}}$$

$a^{2}(p_{x})=\frac{1}{t_{x}^{2}}u^{2}(w)\frac{w^{2}}{t_{x}^{2}}a^{2}$ (t)

$$\left(\frac{u(P_{x})}{P_{x}}\right)^{2}=\frac{u^{2}(w)}{w^{2}}+\frac{u^{2}(t)}{t^{2}}$$

本不确定度分析以榨汁机为例

# 4 标准不确定度一览表

表4-1标准不确定度一览表  

<table border="1"><tr><td>标准不确定度分量 $u_{i}$</td><td>不确定度来源</td><td>标准不确定度值</td><td>$c_{i}=\partial f / \partial x_{i}$</td><td>$\left|c_{i}\right| \times u\left(x_{i}\right)$</td><td>自由度</td></tr><tr><td>$u_{1}$</td><td>重复性误差</td><td>0.2%</td><td>1</td><td>0.2%</td><td>2</td></tr><tr><td>$u_{2}$</td><td>表头示值误差</td><td>0.29%</td><td>1</td><td>0.29%</td><td>50</td></tr><tr><td>$u_{3}$</td><td>电子秒表误差</td><td>0.02%</td><td>1</td><td>0.02%</td><td>8</td></tr></table>

$$u_c(P_x)=0.35\%$$

$$v_{eff}=16$$

2006年06月01日发布

2015年06月01日 第一次修订  
2015年06月01日 偔订实施

2006年07月01日实施