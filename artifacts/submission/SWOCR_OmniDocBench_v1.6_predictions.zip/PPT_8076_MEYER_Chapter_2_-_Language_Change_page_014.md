CAMBRIDGE

# Verb Endings in Romance Languages

Verb Inflections in Four Italic Languages (taken from Rebecca Posner 1996 The Romance Languages. Cambridge University Press, p. 40)

Table 1.1 Regular present indicative person endings in Latin, Spanish, Portuguese and Italian   

<table border="1"><tr><td></td><td>Latin</td><td>Spanish</td><td>Portuguese</td><td>Italian</td></tr><tr><td>1</td><td>-O</td><td>-o</td><td>-o [u]</td><td>-o</td></tr><tr><td>2</td><td>-S</td><td>-s</td><td>-s [ʃ]</td><td>-i</td></tr><tr><td>3</td><td>-T</td><td>Ø</td><td>Ø</td><td>Ø</td></tr><tr><td>4</td><td>-MUS</td><td>-mos</td><td>-mos [muʃ]</td><td>-iamo</td></tr><tr><td>5</td><td>-TIS</td><td>-is</td><td>-is [jʃ]</td><td>-te</td></tr><tr><td>6</td><td>-NT</td><td>-n</td><td>-m [~]</td><td>-no</td></tr></table>

紧 紧 紧

CAMBRIDGE

UNIVERSITY PRESS