# 3. Now read and tick.

make
model ships
(    )

careless
(    )

make
model planes
(    )

cute
(    )

clever
(    )

helpful
(    )

polite
(    )

popular
(    )

active
(    )

quiet
(    )

# B Let's play a guessing game.

Talk about our friends.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_008/image/568C84789FD0A9B02EA9994C9B9F339C_0_433_951_1243_1347.jpeg)

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_008/image/568C84789FD0A9B02EA9994C9B9F339C_0_102_1356_1573_1878.jpeg)

# C  Let's write.

What is Peter like?