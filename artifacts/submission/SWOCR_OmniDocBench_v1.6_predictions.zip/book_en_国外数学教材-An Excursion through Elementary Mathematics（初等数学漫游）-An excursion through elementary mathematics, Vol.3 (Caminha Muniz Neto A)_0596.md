22 Hints and Solutions

3. Start by multiplying equality $a x ^ { 2 } + b x y + c y ^ { 2 } = n$ by 4a and completing squares.   
4. First show that if such $x$ and $y$ did exist, then they would be relatively prime with 122. Then, use the result of the previous problem to conclude that 17 should be a quadratic residue modulo 61. Finally, apply the quadratic reciprocity law and Proposition 12.23 to reach a contradiction.   
5. For item (a), if every prime divisor of $2b^2 + 3$ was congruent to $\pm 1$ modulo 8,
we would have $2b^2 + 3 \equiv \pm 1 \pmod {8}$ ; show that this is impossible. For (b), if
$(2b^2 + 3) \mid (a^2 - 2)$ and $p$ is as in (a), then $a^2 \equiv 2 \pmod {p}$ , so that 2 would
be a quadratic residue modulo $p$ ; use the result of Example 12.27 to reach a
contradiction.   
6. Let $L_n = 2x^2$ . If $n$ is odd, use item (b) of Problem 11, page 252, together with the fact that $L_n$ is even, to show that $n \equiv 3$ or $9 \pmod{12}$ . Then, apply
several times item (e) of this same problem to get $L_n \equiv L_3$ or $L_9 \equiv 4 \pmod{8}$ ,
and show that this gives $x^2 \equiv 2 \pmod{4}$ , which is impossible. Now, assuming
that $n$ is even, consider the following three separate cases: $n \equiv 0 \pmod{4}$ ,
$n \equiv 6 \pmod{8}$ or $n \equiv 2 \pmod{8}$ . If $n \equiv 0 \pmod{4}$ , write $n = 2 \cdot 3^l \cdot k$ , with $k \in \mathbb{Z}$
such that $2 \mid k, 3 \nmid k$ . Argue as in the proof of Example 12.25 to obtain $L_n \equiv$
$-L_0 = -2 \pmod{L_k}$ and, hence, $x^2 \equiv -1 \pmod{L_k}$ . Show that this furnishes
a contradiction, exactly as the one obtained in the proof of Example 12.25. If
$n \equiv 6 \pmod{8}$ but $n = 6$ (note that $L_6 = 18 = 2 \cdot 3^2$ ), write $n = 6 + 2 \cdot 3^l \cdot k$ ,
with $k \in \mathbb{Z}$ such that $4 \mid k$ and $3 \nmid k$ . Use item (d) of Problem 13, page 253, to
obtain $L_n \equiv -L_6 = -18 \pmod{L_k}$ , and hence $x^2 \equiv -9 \pmod{L_k}$ . Also as in
the proof of Example 12.25, conclude that one can take a prime divisor $p$ of $L_k$
such that $p \equiv 3 \pmod{4}$ , so that $x^2 \equiv -9 \pmod{p}$ . Then, show that $3 \nmid L_k$ , so
that $\gcd(p, 9) = 1$ and, thus, $\left(\frac{-9}{p}\right) = \left(\frac{9}{p}\right)\left(\frac{-1}{p}\right) = \left(\frac{-1}{p}\right) = -1$ . Finally, in the
case $n \equiv 2 \pmod{8}$ , just note that $L_{-n} = L_n$ and $-n \equiv 6 \pmod{8}$ .   
7. Let $F_n = x^2$ . If $n \equiv 1 (\bmod 4)$ but $n \neq 1$ , write $n = 1 + 2 \cdot 3^l \cdot k$ , with $k \in \mathbb{Z}$ such that 2 | $k, 3 \nmid k$ . Use item (c) of Problem 13, page 253, to get $F_n \equiv -F_1 = -1 (\bmod L_k)$ ; then, arrive at a contradiction, exactly as in the proof of Example 12.25. If $n \equiv 3 (\bmod 4)$ , use the fact that $F_{-n} = F_n$ and $-n \equiv 1 (\bmod 4)$ . If $n$ is even, write $n = 2m$ and apply item (a) of Problem 13, page 253 to get $F_n = F_m L_m$ . Then, distinguish two distinct subcases: if $\gcd(n, 3) = 1$ , use Problem 12, page 252 to conclude that $L_m$ is also a perfect square; then, apply the result of Example 12.25. If $\gcd(n, 3) = 3$ , use Problem 12, page 252, again to conclude that $L_m$ is twice a perfect square; then, apply the result of the previous problem.   
8. Apply Gauss' lemma, as was done in Example 12.27, or the quadratic reciprocity law.   
9. For item (a), if every prime divisor of $2^n - 1$ was congruent to $\pm 1$ modulo 12,
we would have $2^n - 1 \equiv \pm 1 \pmod {12}$ ; show that this is impossible. For (b), if
$(2^n - 1) \nmid (3^m - 1)$ and $p$ is as in (a), then $3^m \equiv 1 \pmod {p}$ or, which is the
same, $3^{m+1} \equiv 3 \pmod {p}$ ; since $m+1$ is even, it would follow that 3 would be