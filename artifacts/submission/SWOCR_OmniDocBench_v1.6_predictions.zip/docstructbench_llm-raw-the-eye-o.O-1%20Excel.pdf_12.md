EX 12 Excel Chapter 1 Creating a Worksheet and an Embedded Chart

# Formula Bar

The formula bar appears below the Ribbon (Figure 1-12a). As you type, Excel displays the entry in the formula bar. You can make the formula bar larger by dragging the sizing handle (Figure 1-7) on the formula bar or clicking the expand button to the right of the formula bar. Excel also displays the active cell reference in the Name box on the left side of the formula bar.

# Mini Toolbar and Shortcut Menus

The Mini toolbar, which appears automatically based on tasks you perform (such as selecting text), contains commands related to changing the appearance of text in a worksheet. All commands on the Mini toolbar also exist on the Ribbon. The purpose of the Mini toolbar is to minimize mouse movement. For example, if you want to format text using a command that currently is not displayed on the active tab, you can use the command on the Mini toolbar — instead of switching to a different tab to use the command.

When the Mini toolbar appears, it initially is transparent (Figure 1-12a). If you do not use the transparent Mini toolbar, it disappears from the screen. To use the Mini toolbar, move the mouse pointer into the toolbar, which causes the Mini toolbar to change from a transparent to bright appearance (Figure 1-12b).

![](images/docstructbench_llm-raw-the-eye-o.O-1%20Excel.pdf_12/image/8131C4082CC9D7368DA9835B5C5ADF75_0_119_933_779_1270.jpeg)  
(a) Transparent Mini Toolbar

![](images/docstructbench_llm-raw-the-eye-o.O-1%20Excel.pdf_12/image/8131C4082CC9D7368DA9835B5C5ADF75_0_869_933_1566_1268.jpeg)  
(b) Bright Mini Toolbar

![](images/docstructbench_llm-raw-the-eye-o.O-1%20Excel.pdf_12/image/8131C4082CC9D7368DA9835B5C5ADF75_0_116_1462_779_2028.jpeg)  
Figure 1-12   
Figure 1-13

A shortcut menu, which appears when you right-click an object, is a list of frequently used commands that relate to the right-clicked object. If you right-click an item in the document window such as a cell, Excel displays both the Mini toolbar and a shortcut menu (Figure 1-13).