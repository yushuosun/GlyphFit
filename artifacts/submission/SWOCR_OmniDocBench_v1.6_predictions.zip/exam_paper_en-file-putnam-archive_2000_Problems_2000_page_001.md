# The 61st William Lowell Putnam Mathematical Competition Saturday, December 2, 2000

A-1 Let $A$ be a positive real number. What are the possible values of $\sum_{j=0}^{\infty} x_j^2$ , given that $x_0, x_1, \ldots$ are positive numbers for which $\sum_{j=0}^{\infty} x_j = A$ ?

A-2 Prove that there exist infinitely many integers $n$ such
that $n, n + 1, n + 2$ are each the sum of the squares of
two integers. [Example: $0 = 0^2 + 0^2$ , $1 = 0^2 + 1^2$ , $2 =$
$1^2 + 1^2$ .]

A-3 The octagon $P_{1} P_{2} P_{3} P_{4} P_{5} P_{6} P_{7} P_{8}$ is inscribed in a circle, with the vertices around the circumference in the given order. Given that the polygon $P_{1} P_{3} P_{5} P_{7}$ is a square of area 5, and the polygon $P_{2} P_{4} P_{6} P_{8}$ is a rectangle of area 4, find the maximum possible area of the octagon.

A-4 Show that the improper integral

$$\lim_{B\to\infty}\int_0^B\sin(x)\sin(x^2)dx$$

converges.

A-5 Three distinct points with integer coordinates lie in the plane on a circle of radius $r > 0$ . Show that two of these points are separated by a distance of at least $r ^ { 1 / 3 }$ .

A-6 Let $f ( x )$ be a polynomial with integer coefficients. Define a sequence $a _ { 0 } , a _ { 1 } , \ldots$ of integers such that $a _ { 0 } = 0$ and $a _ { n + 1 } = f ( a _ { n } )$ for all $n \geq 0$ . Prove that if there exists a positive integer $m$ for which $a _ { m } = 0$ then either $a _ { 1 } = 0$ or $a _ { 2 } = 0$ .

B-1 Let $a_j, b_j, c_j$ be integers for $1 \leq j \leq N$ . Assume for each
j, at least one of $a_j, b_j, c_j$ is odd. Show that there exist
integers r, s, t such that $ra_j + sb_j + tc_j$ is odd for at least
$4N/7$ values of j, $1 \leq j \leq N$ .

B-2 Prove that the expression

$$\frac{\gcd(m,n)}{n}\binom{n}{m}$$

is an integer for all pairs of integers $n \geq m \geq 1$ .

B-3 Let $f(t) = \sum_{j=1}^{N} a_j \sin(2\pi jt)$ , where each $a_j$ is real and
$a_N$ is not equal to 0. Let $N_k$ denote the number of zeroes
(including multiplicities) of $\frac{d^k f}{dt^k}$ . Prove that

$$N_0\leq N_1\leq N_2\leq\cdots\text{and}\lim_{k\to\infty}N_k=2N.$$

[Editorial clarification: only zeroes in [0,1) should be counted.]

B-4 Let $f ( x )$ be a continuous function such that $f ( 2 x ^ { 2 } - 1 ) = 2 x f ( x )$ for all $x$ . Show that $f ( x ) = 0$ for $- 1 \leq x \leq 1$ .

B-5 Let $S_0$ be a finite set of positive integers. We define
finite sets $S_1, S_2, \ldots$ of positive integers as follows: the
integer $a$ is in $S_{n+1}$ if and only if exactly one of $a-1$ or
$a$ is in $S_n$ . Show that there exist infinitely many integers
$N$ for which $S_N = S_0 \cup \{N+a : a \in S_0\}$ .

B-6 Let $B$ be a set of more than $2^{n+1}/n$ distinct points with coordinates of the form $( \pm 1 , \pm 1 , \ldots , \pm 1 )$ in $n$ -dimensional space with $n \geq 3$ . Show that there are three distinct points in $B$ which are the vertices of an equilateral triangle.