Bull Environ Contam Toxicol (2007) 78:304-307

Velho to Rio Comprido, with 772 m length each roughly. The tunnel cross section is 81 $m^{2}$ in both bores. A concrete wall separates the north-bound traffic from the south-bound traffic. Each gallery has three lanes. CO concentrations and the 1 h average traffic flow are currently monitored. The tunnel ventilation system is composed of 78 fans placed near the roof (Reboucas 2006). The daily traffic volume ranges from 180,000 to 190,000 vehicles $day^{-1}.$ Light duty vehicles (LDV) represent roughly 95% of the local traffic while diesel vehicles and motorcycles account for 2.8% and 2.2% ,respectively (Moreira et al. 2006).

Aromatic compounds were sampled and analyzed using a methodology based on US-EPA methods (1998). Aromatic compounds were sampled by drawing air through tubes 7 cm long, 4 mm ID, containing 2 sections of activated coconut shell charcoal (main section 100 mg ,second section 50 mg ) separated by a 2 mm urethane foam ( SKC Inc ),during 1 h , at a flow rate of $1.0~L~min^{-1}$ The second section of tube was analyzed in order to detect breakthrough.

Charcoal beds in the sorbent tubes were transferred to 2 mL vials and extracted by adding 1.0 mL of $\mathrm{C H_{2} C l_{2}}$ with occasional agitation for 30 min . Bromofluorbenzene was added prior to extraction as internal standard. The samples were analyzed using a Trace GC coupled DSQ Quadrupole Mass Spectrometer (Thermo Finnigan). The column used was a DB-5 ( 5% phenyl-methyl-siloxane) J&W Scientifics,60 m long with 0.25 mm internal diameter and $0. 2 5 \, \mu\mathrm{m}$ thickness phase. Carrier gas was helium at 1 mL $min^{-1}$ and 25 cm $s^{-1}$ linear velocity. The injection mode was splitless with inlet temperature of $2 5 0^{\circ} \mathrm{C}$ .Temperature program was: $4 5^{\circ} \mathrm{C}$ ,held for 2 min, $4 5-2 0 0^{\circ} \mathrm{C}$ at $6^{\circ} \mathrm{C}$ $min^{-1}$ ,held for 5 min .Mass spectrometer ionization was electronic impact and ion source, quadrupole and GC/MS interface temperatures were 230, 150 and $2 5 0^{\circ} \mathrm{C}$ ,respectively.

The MS was run in selective ion monitoring mode. For each compound, two ions (one target and one qualifier) were monitored. Compounds were identified based on their relative retention times and ion ratios. Identified compounds were quantified using internal calibration procedure, with five levels of calibration as follows: 0.1; 1; 5; 25 $\mu\mathrm{g}~\mathrm{m L}^{-1}$ in $\mathrm{C H_{2} C l_{2}},$ with a $\mu\mathrm{g}~\mathrm{m L}^{-1}$ of bromofluorbenzene in all solutions. All calibration solutions were purchased from Supelco. Correlation coefficients were evaluated and 0.99 was considered acceptable.

The reproducibility of the results was checked by analyzing duplicated samples and the difference was always below 10% Blank runs were performed before each sample analyses. The uncertainties of the results were calculated, using the data of the calibration curves, as: benzene 18%,toluene 10%,ethylbenzene 21%,m,p-xylene 8% and o-xylene 12%.

# Results and Discussion

Compounds were monitored in L1 gallery in two locations: station 1 (S1), roughly 500 m from the entrance, and station 2 (S2) about 1000 m apart from S1. A total of five samples were collected, in each location, in 20 October 2005 (at 11:00 am and 1:00 pm) and on 21 October 2005 (at 9:00 am, 11:00 am and 1:00 pm).

Traffic volume through the tunnel is currently counted. As shown in Fig. 1, the fleet profile is quite constant with time between 9:00 am and 8:00 pm . Also the vehicular flux during the two sampling days was very similar to mean values for 2005, showing that those days may be considered representative of the current conditions within the tunnel.

The mean concentrations (5 samples), maximum and minimum values and standard deviations of 14 VACs are summarized in Table 1. The mean mass contribution of each target compound and ratio compound/toluene are also shown.

As shown in Table 1, concentrations in S2 are about 2.4-2.7 higher than in S1 . Also f-test shows that levels in the two locations are statistically different. These were the expected results for a one-way tunnel,where the vehicles enter one direction and the wind speed increases with the passing of cars, creating a piston effect. The entrance of the tunnel may be considered the upwind area and the exit of tunnel becomes downwind (Hsieh et al. 1999). Thus, higher concentrations may be expected in S2, 500 m from the exit of the tunnel.

The profiles of VACs were consistent in both stations, showing nearly the same mass composition. The most abundant species were toluene and xylenes. Although a direct comparison is not valid, since different fuels are used,the same major VACs were reported in other tunnels (Tsai et al. 1997; Chan et al. 1995; Sagebiel et al. 1995; Hsieh et al. 1999). They were also the most abundant VACs in Sao Paulo (Martins et al. 2006a,b). Benzene, toluene, ethylbenzene and xylenes represent 67.3% of the total VACs mixture.

![](images/docstructbench_llm-raw-scihub-o.O-s00128-007-9171-1.pdf_2/image/8D89483EF7DA43BFFB909F02A5816571_0_853_1608_1506_1902.jpeg)  
Fig. 1 Traffic volume for the monitoring campaign period and mean value for 2005 (vehicles per hour)

Springer