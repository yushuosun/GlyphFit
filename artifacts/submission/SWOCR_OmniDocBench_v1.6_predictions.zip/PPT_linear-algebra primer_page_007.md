# Projection: Using Inner Products (I)

![](images/PPT_linear-algebra primer_page_007/image/AFA637E8C1926E792CB9E8ECB48C76DD_0_510_339_1384_955.jpeg)

Projection of $x$ along the direction $\mathbf{a}$ ( $\|\mathbf{a}\|=1$ ).

$$\mathbf{p}=\mathbf{a}(\mathbf{a}^{\mathrm{T}}\mathbf{x})$$

$$\left\|\mathbf{a}\right\|=\mathbf{a}^{\mathrm{T}}\mathbf{a}=1$$

Rensselaer Polytechnic Institute

Shivkumar Kalyanaraman

Google : "shiv rpi"