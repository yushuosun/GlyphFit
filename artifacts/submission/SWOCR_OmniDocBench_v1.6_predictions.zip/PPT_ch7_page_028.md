7.2 Matrix Multiplication

# EXAMPLE 9

# Upper and Lower Triangular Matrices

$$\left[\begin{array}{cc}1&3\\0&2\end{array}\right],$$

$$\left[\begin{array}{ccc}1&4&2\\0&3&2\\0&0&6\end{array}\right],$$

$$\left[\begin{array}{ccc}2&0&0\\8&-1&0\\7&6&8\end{array}\right],$$

$$\left[\begin{array}{cccc}3&0&0&0\\9&-3&0&0\\1&0&2&0\\1&9&3&6\end{array}\right]$$

Upper triangular

Lower triangular

Section 7.2 p28

Advanced Engineering Mathematics, $10/e$ by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.