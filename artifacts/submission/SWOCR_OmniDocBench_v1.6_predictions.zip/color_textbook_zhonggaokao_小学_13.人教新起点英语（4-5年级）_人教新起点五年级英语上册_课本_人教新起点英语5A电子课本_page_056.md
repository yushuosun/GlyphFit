# C  Read,choose and write.

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_056/image/CF89C138E6AF1791D02BD278D5F0FB8B_0_109_236_305_552.jpeg)  
Lucy

Tomorrow is my first day back at school. I want to buy a new schoolbag. First my mum and I go to Xinxin Stationery Shop. I see a big orange bag there. It's 70 yuan. My mum likes it, but I don't like orange. I want a blue bag.

Then we go to Headstart School Shop. There is a blue bag
there. It's 110 yuan, but I only have 100 yuan.

Then we go to Kids Right Shop. There is a blue bag there.
It's small, but it's 60 yuan. I buy it. I'm very happy.

# Which bag does Lucy buy?

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_056/image/CF89C138E6AF1791D02BD278D5F0FB8B_0_216_792_510_1073.jpeg)  
¥

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_056/image/CF89C138E6AF1791D02BD278D5F0FB8B_0_705_790_990_1068.jpeg)  
¥

![](images/color_textbook_zhonggaokao_小学_13.人教新起点英语（4-5年级）_人教新起点五年级英语上册_课本_人教新起点英语5A电子课本_page_056/image/CF89C138E6AF1791D02BD278D5F0FB8B_0_1163_799_1469_1040.jpeg)  
¥

# D Answer the questions and draw your bag.

1. What colour is your school bag?   
2. How much is it?   
3. Do you like it?

Checkpoint   

<table border="1"><tr><td>structures</td><td>vocabulary</td></tr><tr><td>How much is it?It&#x27;s...</td><td>exercise book, pencil sharpener,a pair of scissors, pencil box,a box of crayons, please</td></tr></table>