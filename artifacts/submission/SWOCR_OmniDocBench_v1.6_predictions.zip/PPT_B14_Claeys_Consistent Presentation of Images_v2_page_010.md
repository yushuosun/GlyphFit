# Monitor Characteristic Curve

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_010/image/BEAE01AB9C7C80C2CEE308DCEF7652C3_0_190_747_290_912.jpeg)  
Monitor Characteristic Curve   
Ambient Light

![](images/PPT_B14_Claeys_Consistent Presentation of Images_v2_page_010/image/BEAE01AB9C7C80C2CEE308DCEF7652C3_0_516_431_1536_1132.jpeg)

Slide Provided by David Clunie, Quintiles Intelligent Imaging