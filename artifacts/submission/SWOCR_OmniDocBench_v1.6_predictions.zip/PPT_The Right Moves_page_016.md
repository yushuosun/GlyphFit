# ESL programs at secondary school

![](images/PPT_The Right Moves_page_016/image/FF6C9A5CFC6B845F79E1D12874A51DF9_0_996_0_1998_249.jpeg)

The framework of ESL programs in secondary school
differs significantly from the framework of ESL programs in elementary school.