# HELP + PRON + V

![](images/PPT_session 10_page_022/image/702BE7884C611C459C6D0BE3733E1C01_0_100_420_1876_1045.jpeg)

[help].[vv*] [p*] [v*i]