Chapter 25 Peripheral Nerve Injuries

# ETIOLOGY

Injury to a peripheral nerve can occur by means of several mechanisms: stretching, compression (i.e., sustained compression or blunt trauma), friction, inflammation, or laceration. The clinical results of stretching or compression of the nerve vary depending on whether the insult has a rapid onset or is the result of a gradual change. A sudden insult does not allow for any adaptive change in the connective tissue of the nerve and is more likely to cause acute disruption of the nerve's blood supply or connective tissue. Conversely, the nerve can adapt amazingly well to a slow increase in tensile or compressive forces, such as that brought on by a growing osteophyte. $^{12}$  A classification of peripheral nerve injuries is presented in Table 25-1. $^{13-16}$

# Mechanisms of Peripheral Nerve Injury

• Stretching   
• Compression   
• Friction   
• Inflammation   
Laceration

Compression of the nerve can be caused by external sources or by swelling (e.g., inflammation) with a concomitant increase in pressure in a rigid compartment (e.g., carpal tunnel syndrome [CTS] compressing the median nerve at the wrist or anterior compartment [exertional] syndrome of the leg compressing the deep fibular [peroneal] nerve). $^{17}$  A nerve can be directly compressed,

TABLE 25-1   

<table border="1"><tr><td colspan="5">Classification of Nerve Injuries13-16</td></tr><tr><td>TYPE</td><td colspan="4">FUNCTION</td></tr><tr><td>Seddon&#x27;s Classification</td><td>Sunderland&#x27;s Classification</td><td>Pathological Basis</td><td>Possible Causes</td><td>Prognosis</td></tr><tr><td rowspan="4">Neurapraxia</td><td>Type 1: Focal conduction blockPrimarily motor function and proprioception are affectedSome sensation and sympathetic function possibly present</td><td>Local myelin injury, primarily larger fibersAxonal continuityNo Wallerian degeneration</td><td>Electrolyte imbalancesDeformation of myelin sheathsIschemia caused by compression or traction</td><td>Recovery within minutes, hours, or days if lesion was caused by anoxia or ionic imbalancesMechanical compression or stretch may recover in weeks to months</td></tr><tr><td>Type 2: Loss of nerve conduction at injury site and distally</td><td>Disruption of axonal continuity with Wallerian degenerationConnective tissue elements of the nerve remain intact</td><td>Compression</td><td>Axonal regeneration required for recoveryThe length of time for regeneration will depend on the distance of the injury from the end of the nerveGood prognosis</td></tr><tr><td>Type 3: Loss of nerve conduction at injury site and distally</td><td>Loss of axonal continuity and endoneurial tubesPerineurium and epineurium preserved</td><td>Compression</td><td>Disruption of endoneurial tubes, hemorrhage, and edema, producing scarringAxonal misdirection possiblePoor prognosisSurgery possibly required</td></tr><tr><td>Type 4: Loss of nerve conduction at injury site and distally</td><td>Damage to endoneurium and perineuriumEpineurium remains intact</td><td>Compression</td><td>Intraneural scarring and axonal misdirectionPoor prognosisSurgery required</td></tr><tr><td>Neurotmesis</td><td>Type 5: Loss of nerve conduction at injury site and distally</td><td>Severance of entire nerve</td><td>CompressionTractionLaceration</td><td>Surgical resection and repair only means of recovery; full recovery unlikelyFactors that affect extent of recovery: nerve injured, level at which nerve is damaged, extent of injury, time elapsed since injury, patient&#x27;s age</td></tr></table>

Modified from Dumitru D: Electrodiagnostic medicine, Philadelphia, 1995, Hanley & Belfus.