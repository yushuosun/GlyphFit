$$x_1\quad-2x_2\quad+x_3\quad=0$$

$$2x_{2}\quad-8x_{3}\quad=8$$

$$-3x_2+13x_3=-9$$

$$\left[\begin{array}{cccc}1&-2&1&0\\ 0&2&-8&8\\0&-3&13&-9\end{array}\right]$$

Changing the coefficient of $x_2$ from 2 to 1.

- The purpose of this step is to simplify the calculation in the next steps.   
• To do it, we multiply the $2^{nd}$ equation by $\frac{1}{2}$ .

$$x_1\quad-2x_2\quad+x_3\quad=0$$

$$x_{2}\quad-4x_{3}\quad=4$$

$$-3x_2+13x_3=-9$$

$$\left[\begin{array}{cccc}1&-2&1&0\\ 0&1&-4&4\\0&-3&13&-9\end{array}\right]$$