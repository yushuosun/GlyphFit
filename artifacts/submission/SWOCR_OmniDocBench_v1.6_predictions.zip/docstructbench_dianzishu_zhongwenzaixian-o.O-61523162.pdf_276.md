第二章

创新内核——内壮功

![](images/docstructbench_dianzishu_zhongwenzaixian-o.O-61523162.pdf_276/image/99303E558C26018D2CBED0995E783D78_0_273_211_1238_702.jpeg)  
图 2-68 全面模型黑箱示意图

# （二）模型原理

全面模型总表如下图所示。

表 2-85 全面模型总表  

<table border="1"><tr><td>主题</td><td colspan="9">全面模型总表</td></tr><tr><td>分层分类</td><td>第1类</td><td>第2类</td><td>第3类</td><td>第4类</td><td>第5类</td><td>第6类</td><td>第7类</td><td>第8类</td><td>第9类</td></tr><tr><td>分系统1</td><td>子系统 1-1</td><td>子系统 1-2</td><td>子系统 1-3</td><td>子系统 1-4</td><td>子系统 1-5</td><td>子系统 1-6</td><td>子系统 1-7</td><td>子系统 1-8</td><td>子系统 1-9</td></tr><tr><td>分系统2</td><td>子系统 2-1</td><td>子系统 2-2</td><td>子系统 2-3</td><td>子系统 2-4</td><td>子系统 2-5</td><td>子系统 2-6</td><td>子系统 2-7</td><td>子系统 2-8</td><td>子系统 2-9</td></tr><tr><td>分系统3</td><td>子系统 3-1</td><td>子系统 3-2</td><td>子系统 3-3</td><td>子系统 3-4</td><td>子系统 3-5</td><td>子系统 3-6</td><td>子系统 3-7</td><td>子系统 3-8</td><td>子系统 3-9</td></tr><tr><td>分系统4</td><td>子系统 4-1</td><td>子系统 4-2</td><td>子系统 4-3</td><td>子系统 4-4</td><td>子系统 4-5</td><td>子系统 4-6</td><td>子系统 4-7</td><td>子系统 4-8</td><td>子系统 4-9</td></tr><tr><td>分系统5</td><td>子系统 5-1</td><td>子系统 5-2</td><td>子系统 5-3</td><td>子系统 5-4</td><td>子系统 5-5</td><td>子系统 5-6</td><td>子系统 5-7</td><td>子系统 5-8</td><td>子系统 5-9</td></tr><tr><td>分系统6</td><td>子系统 6-1</td><td>子系统 6-2</td><td>子系统 6-3</td><td>子系统 6-4</td><td>子系统 6-5</td><td>子系统 6-6</td><td>子系统 6-7</td><td>子系统 6-8</td><td>子系统 6-9</td></tr><tr><td>分系统7</td><td>子系统 7-1</td><td>子系统 7-2</td><td>子系统 7-3</td><td>子系统 7-4</td><td>子系统 7-5</td><td>子系统 7-6</td><td>子系统 7-7</td><td>子系统 7-8</td><td>子系统 7-9</td></tr><tr><td>分系统8</td><td>子系统 8-1</td><td>子系统 8-2</td><td>子系统 8-3</td><td>子系统 8-4</td><td>子系统 8-5</td><td>子系统 8-6</td><td>子系统 8-7</td><td>子系统 8-8</td><td>子系统 8-9</td></tr><tr><td>分系统9</td><td>子系统 9-1</td><td>子系统 9-2</td><td>子系统 9-3</td><td>子系统 9-4</td><td>子系统 9-5</td><td>子系统 9-6</td><td>子系统 9-7</td><td>子系统 9-8</td><td>子系统 9-9</td></tr><tr><td>单列总结</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>一句总结</td><td colspan="9"></td></tr><tr><td>九行金句</td><td colspan="9"></td></tr></table>