HOMOGENEOUS LINEAR SYSTEMS

- Solve for the basic variables $x_1$ and $x_2$ to obtain $x_1 = \frac{4}{3}x_3$ , $x_2=0$ , with $x_3$ free.   
As a vector, the general solution of $Ax = 0$ has the form given below.

$$\mathrm X=\left[\begin{array}{c}x_1\\x_2\\x_3\end{array}\right]=\left[\begin{array}{c}\frac{4}{3}x_3\\0\\x_3\end{array}\right]=x_3\left[\begin{array}{c}\frac{4}{3}\\0\\1\end{array}\right]=x_3\mathrm{v,where~v}=\left[\begin{array}{c}\frac{4}{3}\\0\\1\end{array}\right]$$

© 2016 Pearson Education, Inc.