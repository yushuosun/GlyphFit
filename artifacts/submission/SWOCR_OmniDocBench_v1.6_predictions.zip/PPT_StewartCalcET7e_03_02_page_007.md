# The Product Rule

If we divide by $\Delta x$ , we get

$$\frac{\Delta(uv)}{\Delta x}=u\frac{\Delta v}{\Delta x}+v\frac{\Delta u}{\Delta x}+\Delta u\frac{\Delta v}{\Delta x}$$

If we now let $\Delta x \to 0$ , we get the derivative of $uv$ :

$$\frac{d}{dx}\left(uv\right)=\operatorname*{lim}_{\Delta x\to 0}\frac{\Delta(uv)}{\Delta x}=\operatorname*{lim}_{\Delta x\to 0}\left(u\frac{\Delta v}{\Delta x}+v\frac{\Delta u}{\Delta x}+\Delta u\frac{\Delta v}{\Delta x}\right)$$

$$=u\operatorname*{lim}_{\Delta x\to 0}\frac{\Delta v}{\Delta x}+v\operatorname*{lim}_{\Delta x\to 0}\frac{\Delta u}{\Delta x}+\left(\operatorname*{lim}_{\Delta x\to 0}\Delta u\right)\left(\operatorname*{lim}_{\Delta x\to 0}\frac{\Delta v}{\Delta x}\right)$$

$$=u\frac{dv}{dx}+v\frac{du}{dx}+0\cdot\frac{dv}{dx}$$