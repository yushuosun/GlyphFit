# TOP 10 POINTERS FOR A GOOD TALK

6. Use color to emphasize

7. Use illustrations to get across key concepts

• May include limited animation

![](images/PPT_BaharMartonosi_page_005/image/FD9D89C9F1526B58562656BDF05DEBE0_0_1248_525_1790_790.jpeg)

8. Make eye contact

![](images/PPT_BaharMartonosi_page_005/image/FD9D89C9F1526B58562656BDF05DEBE0_0_810_955_1102_1041.jpeg)

9. Be ready to skip slides if time is short

10. Practice !!