# Result Parameter Details

# Peripheral Control Status

The SMPC outputs the peripheral control status to the status register (SR) when the SMPC control mode is used. The status register (SR) is a register that can be read without regard for the INTBACK command. However, when the register is read when the INTBACK command is not in use, all bits except the RESB bit will be undefined.

![](images/docstructbench_llm-raw-the-eye-o.O-ST-169-R1-072694.pdf_76/image/ECB14846E138E57D26DFB6520D479AEE_0_146_517_1409_1405.jpeg)  
Figure 3.13 Peripheral Control Status