# Inference configuration and completion

The release runtime configuration is `configs/ki_ocr_ab.json`. Its mapping to the original run configuration is recorded in `metadata/configuration_equivalence.json`; all computational values are exactly equal. The original bytes are preserved in `history/original_inference_config.json`. Completed page counts and source hashes are in `metadata/RELEASE_STATUS.json` and `evidence/run_completion.json`.

Both arms use the same model, processor and full generation profiles, with a requested output cap and context window of 32768. The 8192-token reserve is input admission headroom. The original-input control uses these settings; it is distinct from upstream author defaults. All thresholds, scale candidates, rendering rules, prompts and dependency hashes are recorded in the configuration.

To rerun inference, use the [R6 source checkout](https://github.com/yushuosun/Ki-OCR/tree/ki-ocr-repro-r6) and its [inference guide](https://github.com/yushuosun/Ki-OCR/blob/ki-ocr-repro-r6/docs/REPRODUCE.md) and [dependencies](https://github.com/yushuosun/Ki-OCR/blob/ki-ocr-repro-r6/docs/DEPENDENCIES.md). This attachment supplies evaluation inputs and numerical evidence, not the external model or GPU dependencies.
