# Ki-OCR evaluation package R6

This package contains the scoring configuration, recorded metrics, prediction manifests and paired evidence for all 1,651 pages of OmniDocBench v1.6_full. The [release index](https://github.com/yushuosun/Ki-OCR/blob/ki-ocr-repro-r6/docs/RELEASE.md) links the matching code and both prediction archives. All project links use the same release tag, `ki-ocr-repro-r6`. The prediction archives contain Markdown only; referenced image crops are not included.

Ki-OCR Overall is **98.40951176937257**; the same-generation original-input control obtains **97.61704895861511**. Exact component metrics and denominators are in `results/RESULTS.json`. Overall is a percentage; component values in that JSON are ratios. See [evidence](EVIDENCE.md) for token accounting and bootstrap scope, and [configuration details](REPRODUCTION.md) for inference settings.

## Evaluate predictions

Download [Ki-OCR predictions](https://github.com/yushuosun/Ki-OCR/raw/ki-ocr-repro-r6/artifacts/submission/Ki-OCR_OmniDocBench_v1.6_predictions.zip) beside this extracted package. From the package directory:

```bash
mkdir -p predictions/GLYPHFIT_FULL
python -m zipfile -e ../Ki-OCR_OmniDocBench_v1.6_predictions.zip predictions/GLYPHFIT_FULL
```

Obtain the [official evaluator](https://github.com/opendatalab/OmniDocBench) at `f133a71e9e91c3621c7ce8994200a7b394a06eb3` and install its CDM/TeX/ImageMagick/Ghostscript dependencies. Obtain GT separately; the expected SHA256 is `a45cd84b04ad8b793e775089640e6b681209abea33ead54c1828ddca35fae496`.

In `configs/end2end.yaml`, set the ground-truth and prediction data paths to absolute paths. Retain quick_match, timeouts 420/300 seconds, fallback span 10, order penalty 0.1 and 8 match/CDM/TEDS workers. Run from the evaluator checkout:

```bash
cd /absolute/path/OmniDocBench
git checkout f133a71e9e91c3621c7ce8994200a7b394a06eb3
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python pdf_validation.py --config /absolute/path/extracted-package/configs/end2end.yaml
```

For the control, extract the [control ZIP](https://github.com/yushuosun/Ki-OCR/raw/ki-ocr-repro-r6/artifacts/submission/Ki-OCR_same_generation_baseline_predictions.zip) separately and use its directory in a copy of the YAML. Both prediction sets can be checked against `evidence/prediction_manifest.json`; the Ki-OCR CLI additionally accepts `metadata/PREDICTION_FILES_SHA256.json` for Ki-OCR predictions.

## Recompute numerical summaries

From this extracted package, using Python 3.11 or newer:

```bash
python -m pip install numpy==2.4.5
python scripts/recompute_statistics.py --evidence evidence --output outputs/recomputed_statistics.json
```

This reconstructs statistics from recorded per-page values; the official evaluator above computes scores from GT and predictions. `FILES_SHA256.json` verifies package members. Source code and original documentation use the [MIT License](LICENSE); [third-party document rights](THIRD_PARTY.md) remain separate.
